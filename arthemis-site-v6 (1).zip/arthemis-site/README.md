# Arthemis (demo)
Marketplace digital fictício. React + Vite + TypeScript + Tailwind v4 + Zustand.

## Rodar (Windows)
1. `setup.bat` (instala dependências) e depois `start.bat`.
2. Login demo: comprador `demo@arthemis.com` / `123456` e vendedor `vendedor@arthemis.com` / `123456` (abas Comprador e Vendedor na tela de login). O acesso administrativo não aparece na tela: as credenciais ficam em `ACCOUNTS`, no arquivo `src/store/index.ts`. Cupom: ARTHEMIS10 (botão "Aplicar" no carrinho).
3. Build: `npm run build`.
4. Banner da home: `public/arthemis-banner.jpg` (já incluído). Para trocar, substitua o arquivo mantendo o mesmo nome.

## Estrutura
- `src/data`: produtos e dados mockados
- `src/store`: carrinho, favoritos, tema, usuário, saldo, pedidos, avaliações, saques e porcentagens (localStorage)
- `src/pages`: Home, Marketplace, Produto, Carrinho, Login, Favoritos, Painel
- `src/extra.tsx`: Checkout PIX, Saldo, páginas institucionais, rodapé
- `src/features`: `vault` (cofre), `sellers` (painel do vendedor), `affiliates` (afiliados e saque PIX), `admin` (inclui "Financeiro"), `wallet` (saque)
- `src/features/events`: página Eventos (premiações, sorteios, disputas) e `AdminEvents.tsx` (criar, editar, excluir, sortear e finalizar, só para admin)
- `src/features/tickets`: botão flutuante de Tickets/denúncias e telas de resposta do Admin
- `src/features/admin/Manage.tsx`: remover/restaurar usuários e vendedores e remover avaliações
- `src/toast.tsx`: avisos na tela, `toast('mensagem')` em qualquer arquivo
- `src/finance.ts`: cálculo das vendas, taxa da plataforma e comissão de afiliado

## Acesso por tipo de conta
- A opção Vendedor não aparece no menu para visitantes nem compradores. Ela só aparece depois do login com conta de vendedor (aba Vendedor na tela de login).
- `/vendedor` abre só para vendedor (ou admin); visitante vai para o login e comprador para o início.

## Cadastro, aprovação e administradores
- **Criar conta** (`/cadastro`, também no cabeçalho e na tela de login): 7 etapas para comprador ou vendedor (tipo, dados pessoais, contato, documento, senha, termos, confirmação). A conta nasce `pending`, vira `under_review` quando um admin abre a análise e termina `approved` ou `rejected`. Login de conta não aprovada mostra a mensagem do status. Após aprovada, entra pela mesma tela de login (aba certa) e vai para o painel existente (comprador: Painel, vendedor: `/vendedor`).
- **Admin 01** é a conta de administrador que já existia em `ACCOUNTS` (`admin@arthemis.com`). Ela tem todas as permissões e é protegida: nenhuma ação do sistema altera, suspende ou remove essa conta. Troque a senha dela em `src/store/index.ts` antes de publicar.
- Admin, novas áreas: **Cadastros pendentes** (CPF mascarado, documento só na tela de análise), **Administradores** (solicitar, aceitar/negar, suspender, remover, permissões) e **Auditoria**. Só o Admin 01 decide solicitações. Ao aceitar, o sistema gera uma senha provisória mostrada uma única vez ao Admin 01.
- Permissões: cada área do Admin e cada ação do store (usuários, vendedores, avaliações, tickets, denúncias, eventos, financeiro) exige a permissão `manage_*` correspondente.
- Código: `src/features/auth` (auth.ts, Register.tsx) e `src/features/admin/Access.tsx`.

### Limite desta versão (importante)
Tudo roda no navegador (localStorage). Senhas novas usam hash PBKDF2 com salt, mas permissões, CPF e documentos **não ficam protegidos de quem abre o DevTools**, e as contas de demonstração continuam com senha no código. Não use com dados reais. Para produção é preciso backend (hash e permissões no servidor, documentos em storage privado, sessões e auditoria no servidor). As funções de `auth.ts` foram isoladas para serem trocadas por chamadas de API.

@echo off
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao encontrado. Instale em https://nodejs.org e rode novamente.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo npm nao encontrado. Reinstale o Node.js.
  pause
  exit /b 1
)
call npm install
if errorlevel 1 (
  echo Falha na instalacao.
  pause
  exit /b 1
)
echo Pronto. Execute start.bat para iniciar.
pause

import { useEffect, useState } from 'react'
import { Link, NavLink, Route, Routes, useLocation, useNavigate } from 'react-router-dom'
import { Heart, Moon, Search, ShoppingCart, Sun } from 'lucide-react'
import { useStore } from './store'
import { Home, Marketplace, ProductPage, CartPage, Login, Favorites, Dashboard } from './pages'
import { Vault } from './features/vault/Vault'
import { SellerPanel } from './features/sellers/SellerPanel'
import { Admin } from './features/admin/Admin'
import { Checkout, Saldo, Sobre, Info, Footer, Logo } from './extra'
import { Toasts } from './toast'
import { Affiliates } from './features/affiliates/Affiliates'
import { Events } from './features/events/Events'
import { TicketFab } from './features/tickets/Tickets'
import { Register } from './features/auth/Register'
import { useAuth, useMe } from './features/auth/auth'

function Header() {
  const { cart, theme, toggleTheme, user, logout, balance, role } = useStore()
  const [q, setQ] = useState('')
  const [menu, setMenu] = useState(false)
  const nav = useNavigate()
  const count = Object.values(cart).reduce((a, b) => a + b, 0)
  const link = ({ isActive }: { isActive: boolean }) => (isActive ? 'text-primary' : 'text-muted hover:text-foreground')
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3">
        <button className="md:hidden" aria-label="Menu" aria-expanded={menu} onClick={() => setMenu(!menu)}>☰</button>
        <Link to="/" className="flex items-center gap-2 font-display text-xl tracking-tight"><Logo /><span><span className="text-primary">ART</span>HEMIS</span></Link>
        <Link to="/carrinho" aria-label="Carrinho" className="ml-auto md:hidden">🛒{count > 0 ? ` ${count}` : ''}</Link>
        <form className="relative order-last w-full md:order-none md:w-auto md:flex-1" onSubmit={(e) => { e.preventDefault(); nav(`/marketplace?q=${encodeURIComponent(q)}`) }}>
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted" />
          <input aria-label="Pesquisar produtos" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Pesquisar produtos..." className="input pl-9" />
        </form>
        <nav className="hidden items-center gap-4 text-sm md:flex">
          <NavLink to="/marketplace" className={link}>Explorar</NavLink>
          <NavLink to="/dashboard" className={link}>Painel</NavLink>
          <NavLink to="/cofre" className={link}>Cofre</NavLink>
          {role === 'seller' && <NavLink to="/vendedor" className={link}>Vendedor</NavLink>}
          {role === 'admin' && <NavLink to="/admin" className={link}>Admin</NavLink>}
          <NavLink to="/eventos" className={link}>Eventos</NavLink>
          <NavLink to="/afiliados" className={link}>Afiliados</NavLink>
          <NavLink to="/saldo" className={link}>Saldo {balance.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}</NavLink>
          <Link to="/favoritos" aria-label="Favoritos"><Heart className="h-5 w-5" /></Link>
          <Link to="/carrinho" aria-label="Carrinho" className="relative"><ShoppingCart className="h-5 w-5" />{count > 0 && <span className="absolute -right-2 -top-2 rounded-full bg-primary px-1.5 text-[10px] text-on-primary">{count}</span>}</Link>
          <button aria-label="Alternar tema" onClick={toggleTheme}>{theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}</button>
          {user ? <button onClick={logout} className="text-muted">Sair</button> : <><Link to="/cadastro" className="text-muted hover:text-foreground">Criar conta</Link><Link to="/login" className="btn btn-primary btn-sm">Entrar</Link></>}
        </nav>
      </div>
      {menu && <nav aria-label="Menu" className="flex flex-col gap-3 border-t border-border p-4 md:hidden" onClick={() => setMenu(false)}><Link to="/marketplace">Explorar</Link><Link to="/cofre">Cofre digital</Link>{role === 'seller' && <Link to="/vendedor">Painel do vendedor</Link>}{role === 'admin' && <Link to="/admin">Admin</Link>}<Link to="/eventos">Eventos</Link><Link to="/afiliados">Afiliados</Link><Link to="/saldo">Saldo</Link><Link to="/sobre">Sobre</Link>{!user && <Link to="/cadastro">Criar conta</Link>}</nav>}
    </header>
  )
}

function BottomNav() {
  const items: [string, string, string][] = [['/', '🏠', 'Início'], ['/marketplace', '🔎', 'Buscar'], ['/favoritos', '❤️', 'Favoritos'], ['/carrinho', '🛒', 'Carrinho'], ['/dashboard', '👤', 'Conta']]
  return (
    <nav aria-label="Navegação principal" className="fixed inset-x-0 bottom-0 z-40 flex justify-around border-t border-border bg-background/90 py-2 backdrop-blur md:hidden">
      {items.map(([to, icon, label]) => (
        <NavLink key={to} to={to} end aria-label={label} className={({ isActive }) => `flex flex-col items-center text-xs ${isActive ? 'text-primary' : 'text-muted'}`}><span className="text-lg">{icon}</span>{label}</NavLink>
      ))}
    </nav>
  )
}

export default function App() {
  const theme = useStore((s) => s.theme)
  const setRef = useStore((s) => s.setRef)
  const { email, role, logout } = useStore()
  const registered = useAuth((s) => s.users.some((u) => u.email === email))
  const active = useMe()
  // Conta suspensa ou removida perde a sessão na hora
  useEffect(() => { if (email && !active && (registered || role === 'admin')) logout() }, [email, role, registered, active, logout])
  const { search } = useLocation()
  useEffect(() => { const r = new URLSearchParams(search).get('ref'); if (r) setRef(r.toUpperCase().slice(0, 20)) }, [search, setRef])
  useEffect(() => { document.documentElement.dataset.theme = theme }, [theme])
  return (
    <>
      <Header />
      <main className="mx-auto max-w-6xl px-4 pb-24 pt-8 md:pb-8">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/marketplace" element={<Marketplace />} />
          <Route path="/produto/:slug" element={<ProductPage />} />
          <Route path="/carrinho" element={<CartPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/cadastro" element={<Register />} />
          <Route path="/favoritos" element={<Favorites />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/cofre" element={<Vault />} />
          <Route path="/vendedor" element={<SellerPanel />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/afiliados" element={<Affiliates />} />
          <Route path="/eventos" element={<Events />} />
          <Route path="/saldo" element={<Saldo />} />
          <Route path="/sobre" element={<Sobre />} />
          <Route path="/p/:slug" element={<Info />} />
          <Route path="*" element={<p className="py-20 text-center text-muted">404: página não encontrada.</p>} />
        </Routes>
      </main>
      <Footer />
      <BottomNav />
      <Toasts />
      <TicketFab />
    </>
  )
}

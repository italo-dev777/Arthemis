import { useEffect, type ReactNode } from 'react'

// Janela de confirmação usada antes de qualquer remoção no Admin
export function Confirm({ title, children, confirmLabel = 'Remover', onConfirm, onCancel }: { title: string; children: ReactNode; confirmLabel?: string; onConfirm: () => void; onCancel: () => void }) {
  useEffect(() => { const k = (e: KeyboardEvent) => e.key === 'Escape' && onCancel(); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k) }, [onCancel])
  return (
    <div className="fixed inset-0 z-[60] grid place-items-center bg-black/60 p-4" role="dialog" aria-modal="true" aria-label={title} onClick={onCancel}>
      <div className="card w-full max-w-md space-y-4 p-6 shadow-e3" onClick={(e) => e.stopPropagation()}>
        <h2 className="text-xl">{title}</h2>
        <div className="space-y-1 text-sm">{children}</div>
        <div className="flex justify-end gap-2"><button className="btn btn-ghost" onClick={onCancel}>Cancelar</button><button className="btn btn-primary" onClick={onConfirm}>{confirmLabel}</button></div>
      </div>
    </div>
  )
}

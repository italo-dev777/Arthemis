const ROWS: [string, number][] = [['Entrega', 98], ['Qualidade', 96], ['Suporte', 94], ['Confiabilidade', 99]]
export function ArthemisScore() {
  return (
    <section className="card space-y-3 p-5" aria-label="Arthemis Score">
      <p className="eyebrow">Arthemis Score</p>
      {ROWS.map(([k, v]) => (
        <div key={k}>
          <div className="flex justify-between text-sm"><span>{k}</span><span>{v}%</span></div>
          <div className="h-1.5 rounded-full bg-border"><div className="h-full rounded-full bg-primary" style={{ width: `${v}%` }} /></div>
        </div>
      ))}
      <p className="text-lg"><span className="text-warning">★★★★★</span> <b>4.9</b></p>
    </section>
  )
}

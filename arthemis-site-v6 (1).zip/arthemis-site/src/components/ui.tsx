import { useEffect, useMemo, useState } from 'react'
import { Star } from 'lucide-react'
import { brl, products, type Product } from '../data'
import { useStore, type Review } from '../store'

// Catálogo sem os produtos de vendedores removidos pelo Admin
export function useCatalog() {
  const gone = useStore((s) => s.removed.sellers)
  return useMemo(() => products.filter((p) => !gone.includes(p.seller)), [gone])
}
export function useLoading(ms = 500) {
  const [l, setL] = useState(true)
  useEffect(() => { const t = setTimeout(() => setL(false), ms); return () => clearTimeout(t) }, [ms])
  return l
}
// Nota exibida: nota do produto combinada com as avaliações feitas por compradores
export const rate = (p: Product, rs: Review[]) => {
  const r = rs.filter((x) => x.slug === p.slug)
  return { avg: (p.rating * 20 + r.reduce((a, x) => a + x.rating, 0)) / (20 + r.length), n: r.length }
}
export function Stars({ value, onChange }: { value: number; onChange?: (n: number) => void }) {
  return (
    <span className="inline-flex" role={onChange ? 'radiogroup' : 'img'} aria-label={`Nota ${value.toFixed(1)} de 5`}>
      {[1, 2, 3, 4, 5].map((n) => (
        <button key={n} type="button" disabled={!onChange} onClick={() => onChange?.(n)} aria-label={`${n} estrelas`} className="disabled:cursor-default">
          <Star className={`h-5 w-5 ${n <= Math.round(value) ? 'fill-warning text-warning' : 'text-muted'}`} />
        </button>
      ))}
    </span>
  )
}
export function Price({ p, big }: { p: Product; big?: boolean }) {
  const off = p.old ? Math.round((1 - p.price / p.old) * 100) : 0
  return (
    <div className="flex flex-wrap items-baseline gap-2">
      <span className={`font-bold text-primary ${big ? 'text-4xl' : 'text-xl'}`}>{brl(p.price)}</span>
      {p.old && <><span className={`text-muted line-through ${big ? 'text-base' : 'text-xs'}`}>{brl(p.old)}</span><span className="badge badge-success">-{off}%</span></>}
    </div>
  )
}
export function SkeletonCard() {
  return (
    <div className="card overflow-hidden" aria-hidden="true">
      <div className="skeleton h-36 rounded-none" />
      <div className="space-y-2 p-4"><div className="skeleton h-3 w-1/3" /><div className="skeleton h-4 w-3/4" /><div className="skeleton h-3 w-1/2" /><div className="skeleton h-6 w-1/3" /></div>
    </div>
  )
}

export interface Page { title: string; intro: string; items: [string, string][]; cta?: [string, string] }
const AVISO: [string, string] = ['Aviso', 'Texto de demonstração. Revise com um profissional jurídico antes de publicar o site de verdade.']
export const PAGES: Record<string, Page> = {
  anunciar: { title: 'Anunciar', intro: 'Venda seus produtos digitais para milhares de compradores, de forma simples e segura.', items: [
    ['1. Crie sua conta', 'Cadastre-se gratuitamente e acesse o seu painel de vendedor.'],
    ['2. Publique seu anúncio', 'Informe título, categoria, descrição, preço e forma de entrega. Anunciar não tem custo.'],
    ['3. Receba pedidos', 'Você é avisado a cada venda e entrega o produto pelo chat do pedido.'],
    ['4. Receba seus ganhos', 'O valor é liberado após a confirmação da entrega e pode ser sacado via PIX.']], cta: ['Acessar meu painel', '/dashboard'] },
  blog: { title: 'Blog', intro: 'Dicas e novidades para quem compra e vende no mercado digital.', items: [
    ['Como identificar uma conta de jogo confiável', 'Confira o histórico do vendedor, peça provas da conta e nunca negocie fora da plataforma.'],
    ['Boas práticas para vender gift cards com segurança', 'Descreva o valor e a região do cartão, responda rápido e entregue o código pelo chat do pedido.'],
    ['Streaming e música: como escolher a assinatura ideal', 'Compare número de telas, qualidade de áudio e vídeo, e o tempo de duração de cada plano.'],
    ['PIX: como pagar com copia e cola e QR Code', 'Gere o PIX no checkout, copie o código ou leia o QR Code e confirme o pagamento no app do seu banco.']] },
  'perguntas-frequentes': { title: 'Perguntas frequentes', intro: 'Respostas rápidas para as dúvidas mais comuns.', items: [
    ['Como faço uma compra?', 'Escolha o produto, adicione ao carrinho e pague com PIX no checkout.'],
    ['Como recebo o que comprei?', 'A entrega é digital e acontece pelo chat do pedido, assim que o pagamento for confirmado.'],
    ['Quais formas de pagamento existem?', 'Somente PIX, por QR Code ou copia e cola. Você também pode usar o saldo da sua conta.'],
    ['Como adiciono saldo?', 'Acesse a aba Saldo, escolha o valor e pague o PIX gerado.'],
    ['Posso pedir reembolso?', 'Sim, se o produto não for entregue ou não corresponder ao anúncio. Veja a política de reembolso.'],
    ['Qual é a taxa da plataforma?', 'Na demonstração, a taxa de serviço é de 3% sobre o valor da compra.']] },
  'central-de-ajuda': { title: 'Central de Ajuda', intro: 'Escolha um assunto ou fale com o nosso suporte.', items: [
    ['Compras', 'Acompanhe pedidos, receba produtos e avalie vendedores.'],
    ['Vendas', 'Crie anúncios, gerencie pedidos e acompanhe seus ganhos.'],
    ['Pagamentos e saldo', 'Pague com PIX, adicione saldo e solicite saques.'],
    ['Conta e segurança', 'Proteja seu acesso: use senha forte e nunca compartilhe códigos de verificação.'],
    ['Reembolsos', 'Abra uma solicitação em até 7 dias após a compra.'],
    ['Contato', 'Escreva para suporte@arthemis.com. Respondemos em até 24 horas.']] },
  'como-funciona': { title: 'Como funciona', intro: 'Comprar e vender na Arthemis é rápido e protegido.', items: [
    ['Para quem compra: 1. Encontre', 'Pesquise ou navegue pelas categorias e compare vendedores.'],
    ['2. Pague com PIX', 'O pagamento fica protegido pela plataforma até a entrega.'],
    ['3. Receba', 'O vendedor entrega o produto digital pelo chat do pedido.'],
    ['4. Avalie', 'Confirme o recebimento e avalie o vendedor.'],
    ['Para quem vende: publique, receba e saque', 'Crie o anúncio, entregue o pedido e receba o valor via PIX após a confirmação.']] },
  vantagens: { title: 'Vantagens', intro: 'Por que escolher a Arthemis.', items: [
    ['Compra protegida', 'O valor só é liberado ao vendedor depois da entrega.'],
    ['Entrega digital rápida', 'Receba seu produto logo após a confirmação do PIX.'],
    ['Vendedores avaliados', 'Reputação transparente, com notas e comentários de compradores reais.'],
    ['Pagamento por PIX', 'Confirmação rápida, por QR Code ou copia e cola.'],
    ['Suporte dedicado', 'Ajuda para compradores e vendedores.'],
    ['Programa de recompensa', 'Quem usa mais ganha mais benefícios.']] },
  'tarifas-e-prazos': { title: 'Tarifas e prazos', intro: 'Valores de demonstração, sujeitos a alteração.', items: [
    ['Criar anúncio', 'Gratuito.'],
    ['Taxa de serviço', '3% sobre o valor de cada compra.'],
    ['Adicionar saldo', 'Sem taxa, via PIX.'],
    ['Liberação ao vendedor', 'Após a confirmação do comprador ou em até 24 horas da entrega.'],
    ['Saque', 'Via PIX, em até 1 dia útil após a solicitação.']] },
  'formas-de-pagamento': { title: 'Formas de pagamento', intro: 'Aceitamos exclusivamente PIX.', items: [
    ['PIX QR Code', 'Abra o app do seu banco, leia o QR Code e confirme.'],
    ['PIX copia e cola', 'Copie o código no checkout e cole no app do seu banco.'],
    ['Saldo da conta', 'Adicione saldo via PIX na aba Saldo.'],
    ['Segurança', 'Pague somente dentro da plataforma. Nunca envie PIX diretamente ao vendedor.']], cta: ['Adicionar saldo', '/saldo'] },
  verificador: { title: 'Verificador de contas', intro: 'Um passo a passo para conferir uma conta antes de confirmar a compra.', items: [
    ['1. Confira os dados', 'Compare nível, itens e região com o que foi anunciado.'],
    ['2. Peça provas', 'Solicite capturas de tela e informações pelo chat do pedido.'],
    ['3. Troque os acessos', 'Altere e-mail e senha assim que receber a conta.'],
    ['4. Confirme só depois', 'Marque o pedido como recebido apenas depois de verificar tudo.'],
    ['Algo errado?', 'Abra uma disputa pelo pedido antes de confirmar o recebimento.']] },
  'termos-de-uso': { title: 'Termos de uso', intro: 'Regras para usar a Arthemis.', items: [
    ['Cadastro', 'Você deve fornecer informações verdadeiras e manter seu acesso em segurança.'],
    ['Conduta', 'É proibido anunciar itens ilegais, fraudulentos ou que violem direitos de terceiros.'],
    ['Pagamentos', 'Todas as transações ocorrem dentro da plataforma, via PIX.'],
    ['Responsabilidades', 'O vendedor responde pelo produto anunciado e pela entrega.'],
    ['Alterações', 'Estes termos podem ser atualizados, e os usuários serão avisados.'], AVISO] },
  'programa-de-recompensa': { title: 'Programa de recompensa', intro: 'Quanto mais você participa, mais benefícios recebe.', items: [
    ['Como ganhar pontos', 'Compras concluídas, avaliações e vendas bem avaliadas geram pontos.'],
    ['Bronze', 'Nível inicial, com acesso a cupons ocasionais.'],
    ['Prata', 'Cupons maiores e acesso antecipado a promoções.'],
    ['Ouro', 'Cupons exclusivos e suporte prioritário.'],
    ['Observação', 'Programa de demonstração, os níveis e benefícios podem mudar.']] },
  'politica-de-privacidade': { title: 'Política de privacidade', intro: 'Como tratamos os seus dados.', items: [
    ['Dados coletados', 'Nome, e-mail, nome de usuário e histórico de pedidos.'],
    ['Uso dos dados', 'Operar a plataforma, prevenir fraudes e melhorar a experiência.'],
    ['Compartilhamento', 'Não vendemos seus dados. Compartilhamos apenas o necessário para concluir transações ou cumprir a lei.'],
    ['Seus direitos', 'Você pode pedir acesso, correção ou exclusão dos seus dados em privacidade@arthemis.com.'],
    ['Segurança', 'Adotamos medidas técnicas para proteger as informações.'], AVISO] },
  'politica-de-reembolso': { title: 'Política de reembolso', intro: 'Quando e como você pode pedir o dinheiro de volta.', items: [
    ['Quando é possível', 'Produto não entregue, diferente do anunciado ou com defeito comprovado.'],
    ['Prazo', 'Abra a solicitação em até 7 dias após a compra.'],
    ['Como pedir', 'Acesse o pedido, clique em disputa e descreva o problema com provas.'],
    ['Análise', 'Nossa equipe analisa o caso e responde em até 48 horas.'],
    ['Devolução', 'Aprovado o reembolso, o valor volta como saldo na sua conta ou via PIX.'], AVISO] },
  'trabalhe-conosco': { title: 'Trabalhe conosco', intro: 'Venha construir o mercado digital com a gente.', items: [
    ['Desenvolvimento front-end', 'React e TypeScript, trabalho remoto.'],
    ['Suporte ao cliente', 'Atendimento a compradores e vendedores.'],
    ['Marketing e comunidade', 'Conteúdo, parcerias e relacionamento com criadores.'],
    ['Como se candidatar', 'Envie seu currículo para carreiras@arthemis.com. Vagas de demonstração.']] },
}

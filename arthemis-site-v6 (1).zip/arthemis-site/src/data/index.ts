export interface Product { slug: string; name: string; cat: string; seller: string; price: number; old?: number; rating: number; sales: number; emoji: string }
export const categories = [
  { id: 'contas', name: 'Contas de jogos', emoji: '🎮' },
  { id: 'gift-cards', name: 'Gift Cards', emoji: '🎁' },
  { id: 'jogos', name: 'Jogos', emoji: '🕹️' },
  { id: 'streaming', name: 'Streaming', emoji: '📺' },
  { id: 'musica', name: 'Música', emoji: '🎧' },
]
type Row = [string, string, string, string, number, number | undefined, number, number, string]
const rows: Row[] = [
  ['minecraft-premium', 'Minecraft Premium Account', 'contas', 'DigitalStore', 49.9, 79.9, 4.9, 1240, '⛏️'],
  ['gift-card-steam-50', 'Gift Card Steam R$ 50', 'gift-cards', 'GiftHub', 48.5, undefined, 4.8, 3120, '🎁'],
  ['gift-card-roblox', 'Gift Card Roblox R$ 100', 'gift-cards', 'GiftHub', 95, 100, 4.7, 2210, '🧱'],
  ['conta-valorant', 'Conta Valorant Full Acesso', 'contas', 'ProGamer', 120, 150, 4.4, 220, '🎯'],
  ['gift-card-psn', 'Gift Card PlayStation R$ 100', 'gift-cards', 'GiftHub', 92, 100, 4.8, 1890, '🕹️'],
  ['conta-fortnite', 'Conta Fortnite com Skins Raras', 'contas', 'ProGamer', 85, 129.9, 4.6, 340, '🪂'],
  ['gift-card-xbox', 'Gift Card Xbox R$ 50', 'gift-cards', 'CardZone', 47.9, undefined, 4.7, 950, '🟩'],
  ['conta-lol', 'Conta League of Legends Nível 30', 'contas', 'ProGamer', 39.9, 59.9, 4.5, 410, '⚔️'],
  ['gta-v-premium', 'GTA V Edição Premium (chave)', 'jogos', 'GameKeys', 59.9, 89.9, 4.8, 860, '🚗'],
  ['moedas-fc-100k', 'Moedas FC 100k', 'jogos', 'CoinPlace', 69.9, undefined, 4.5, 540, '⚽'],
  ['robux-1000', '1.000 Robux', 'jogos', 'GiftHub', 44.9, undefined, 4.7, 2000, '💎'],
  ['netflix-1-mes', 'Assinatura Netflix 1 mês', 'streaming', 'StreamPlus', 19.9, 39.9, 4.6, 1520, '🎬'],
  ['disney-plus-3-meses', 'Disney+ 3 meses', 'streaming', 'StreamPlus', 44.9, 59.9, 4.7, 610, '🏰'],
  ['max-1-mes', 'Max 1 mês', 'streaming', 'StreamPlus', 17.9, undefined, 4.5, 430, '🍿'],
  ['spotify-premium-3-meses', 'Spotify Premium 3 meses', 'musica', 'MusicBox', 34.9, 59.9, 4.8, 1730, '🎧'],
  ['deezer-premium', 'Deezer Premium 1 mês', 'musica', 'MusicBox', 9.9, undefined, 4.4, 320, '🎵'],
  ['youtube-music', 'YouTube Music Premium 1 mês', 'musica', 'MusicBox', 12.9, 21.9, 4.6, 480, '▶️'],
]
export const products: Product[] = rows.map(([slug, name, cat, seller, price, old, rating, sales, emoji]) => ({ slug, name, cat, seller, price, old, rating, sales, emoji }))
export const brl = (n: number) => n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
export const info: Record<string, { includes: string[]; requires: string[] }> = {
  contas: { includes: ['Dados de acesso da conta (e-mail e senha)', 'Orientações para trocar os acessos'], requires: ['Plataforma do jogo instalada', 'E-mail próprio para recuperar a conta'] },
  'gift-cards': { includes: ['Código de resgate digital', 'Instruções de resgate'], requires: ['Conta ativa na plataforma', 'Mesma região do cartão'] },
  jogos: { includes: ['Chave de ativação ou crédito no jogo', 'Guia de ativação'], requires: ['Conta na plataforma do jogo', 'Computador ou console compatível'] },
  streaming: { includes: ['Acesso à assinatura pelo período contratado', 'Passo a passo de login'], requires: ['Aparelho com o app instalado', 'Conexão com a internet'] },
  musica: { includes: ['Acesso premium pelo período contratado', 'Passo a passo de ativação'], requires: ['App instalado no celular ou computador', 'Conta própria no serviço'] },
}

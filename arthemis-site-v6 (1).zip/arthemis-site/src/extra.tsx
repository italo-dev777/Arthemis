import { useEffect, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Copy } from 'lucide-react'
import { brl } from './data'
import { useCatalog } from './components/ui'
import { useStore } from './store'
import { PAGES } from './content'
import { toast } from './toast'

const SOBRE = 'Somos a solução para o mercado digital, com uma plataforma moderna em que o comprador recebe o produto ou serviço desejado e o vendedor recebe pela sua venda. Tudo com praticidade e segurança.'

// QR fictício e determinístico, apenas para demonstração (não é escaneável)
function FakeQR({ seed }: { seed: string }) {
  const n = 25
  let h = 0
  for (const c of seed) h = (h * 31 + c.charCodeAt(0)) >>> 0
  const rnd = () => { h = (h * 1664525 + 1013904223) >>> 0; return h / 2 ** 32 }
  const finders = [[0, 0], [n - 7, 0], [0, n - 7]]
  const cells = []
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
    let on = rnd() > 0.5
    for (const [fx, fy] of finders) {
      if (x >= fx && x < fx + 7 && y >= fy && y < fy + 7) {
        const dx = x - fx, dy = y - fy
        on = dx === 0 || dy === 0 || dx === 6 || dy === 6 || (dx >= 2 && dx <= 4 && dy >= 2 && dy <= 4)
      }
    }
    if (on) cells.push(<rect key={`${x}-${y}`} x={x} y={y} width="1" height="1" />)
  }
  return (
    <svg viewBox={`-1 -1 ${n + 2} ${n + 2}`} className="h-48 w-48 rounded-xl" role="img" aria-label="QR Code PIX de demonstração">
      <rect x="-1" y="-1" width={n + 2} height={n + 2} fill="#fff" /><g fill="#000">{cells}</g>
    </svg>
  )
}

function PixBox({ amount, seed, onPaid }: { amount: number; seed: string; onPaid: () => void }) {
  const [copied, setCopied] = useState(false)
  const code = `00020126580014BR.GOV.BCB.PIX0136demo-arthemis-${seed}5204000053039865406${amount.toFixed(2)}5802BR5908ARTHEMIS6009SAO PAULO6304DEMO`
  const copy = () => { navigator.clipboard?.writeText(code); toast('Código PIX copiado'); setCopied(true); setTimeout(() => setCopied(false), 2000) }
  return (
    <div className="space-y-4 card p-5">
      <p className="font-semibold">Pague {brl(amount)} com PIX</p>
      <div className="flex flex-col items-center gap-4 md:flex-row">
        <FakeQR seed={seed + amount} />
        <div className="w-full space-y-2">
          <p className="text-sm text-muted">PIX copia e cola</p>
          <textarea readOnly value={code} aria-label="Código PIX copia e cola" className="input h-24 py-2 text-xs" />
          <button onClick={copy} className="btn btn-ghost btn-sm"><Copy className="h-4 w-4" />{copied ? 'Código copiado!' : 'Copiar código'}</button>
        </div>
      </div>
      <button onClick={onPaid} className="btn btn-primary w-full">Já paguei (simular pagamento)</button>
      <p className="text-xs text-muted">Demonstração: QR Code e código fictícios, nenhum pagamento real é feito.</p>
    </div>
  )
}

const STEPS = ['Carrinho', 'Revisão', 'Pagamento', 'Processando', 'Pagamento aprovado', 'Produto liberado']
function Steps({ active }: { active: number }) {
  return (
    <ol className="grid grid-cols-2 gap-2 text-xs sm:grid-cols-3 md:grid-cols-6">
      {STEPS.map((s, i) => (
        <li key={s} aria-current={i === active ? 'step' : undefined} className={`rounded-md border p-2 text-center ${i < active ? 'border-success text-success' : i === active ? 'border-primary text-primary' : 'border-border text-muted'}`}>{String(i + 1).padStart(2, '0')} {s}</li>
      ))}
    </ol>
  )
}

export function Checkout() {
  const { cart, clear, placeOrder } = useStore()
  const products = useCatalog()
  const state = useLocation().state as { coupon?: string } | null
  const [seed] = useState(() => Math.random().toString(36).slice(2, 8).toUpperCase())
  const [stage, setStage] = useState(0)
  const [paid, setPaid] = useState<{ id: string; total: number } | null>(null)
  useEffect(() => {
    if (stage !== 3 && stage !== 4) return
    const t = setTimeout(() => setStage(stage + 1), stage === 3 ? 2000 : 1500)
    return () => clearTimeout(t)
  }, [stage])
  const items = Object.entries(cart).map(([id, qty]) => ({ p: products.find((x) => x.slug === id)!, qty })).filter((i) => i.p)
  const subtotal = items.reduce((a, i) => a + i.p.price * i.qty, 0)
  const discount = state?.coupon?.toUpperCase() === 'ARTHEMIS10' ? subtotal * 0.1 : 0
  const total = subtotal - discount + subtotal * 0.03
  if (stage < 3 && !items.length) return <div className="py-20 text-center text-muted"><p>Seu carrinho está vazio.</p><Link to="/marketplace" className="text-primary">Explorar marketplace</Link></div>
  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <Steps active={stage} />
      {stage < 2 && (
        <div className="card p-5 text-sm">
          {items.map(({ p, qty }) => <p key={p.slug} className="flex justify-between py-1"><span>{p.emoji} {p.name} × {qty}</span>{brl(p.price * qty)}</p>)}
          {stage === 1 && <><p className="flex justify-between pt-2 text-muted"><span>Desconto</span>-{brl(discount)}</p><p className="flex justify-between text-muted"><span>Taxa (3%)</span>{brl(subtotal * 0.03)}</p></>}
          <p className="flex justify-between pt-2 text-lg font-bold"><span>Total</span>{brl(stage === 1 ? total : subtotal)}</p>
        </div>
      )}
      {stage === 0 && <button className="btn btn-primary w-full" onClick={() => setStage(1)}>Continuar para a revisão</button>}
      {stage === 1 && <div className="flex gap-2"><button className="btn btn-ghost" onClick={() => setStage(0)}>Voltar</button><button className="btn btn-primary flex-1" onClick={() => setStage(2)}>Ir para o pagamento</button></div>}
      {stage === 2 && <PixBox amount={total} seed={seed} onPaid={() => { setPaid({ id: seed, total }); placeOrder(items.map(({ p, qty }) => ({ slug: p.slug, qty })), total); clear(); toast('Pagamento recebido, processando...'); setStage(3) }} />}
      {stage === 3 && <div className="card space-y-2 p-8 text-center" role="status"><p className="animate-pulse text-4xl">⏳</p><p>Processando o pagamento...</p></div>}
      {stage === 4 && <div className="card space-y-2 p-8 text-center" role="status"><p className="text-4xl">✅</p><p className="font-semibold">Pagamento aprovado</p><p className="text-sm text-muted">Pedido #{paid?.id} · {brl(paid?.total ?? 0)}</p></div>}
      {stage === 5 && <div className="card space-y-3 p-8 text-center"><p className="text-4xl">🎉</p><h1 className="text-2xl">Produto liberado!</h1><Link to="/cofre" className="btn btn-primary">Acessar meu cofre digital</Link></div>}
    </div>
  )
}

export function Saldo() {
  const { balance, addBalance } = useStore()
  const [amount, setAmount] = useState(50)
  const [gen, setGen] = useState(false)
  const [ok, setOk] = useState(false)
  const [seed, setSeed] = useState('SALDO')
  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <h1 className="text-2xl font-bold">Adicionar saldo</h1>
      <div className="card p-5"><p className="text-sm text-muted">Saldo disponível</p><p className="text-3xl font-bold">{brl(balance)}</p></div>
      {ok && <p className="alert alert-success">Saldo adicionado com sucesso (simulado).</p>}
      {!gen ? (
        <div className="space-y-3 card p-5">
          <div className="flex flex-wrap gap-2">{[20, 50, 100, 200].map((v) => <button key={v} onClick={() => setAmount(v)} className={`chip ${amount === v ? 'chip-active' : ''}`}>{brl(v)}</button>)}</div>
          <label className="block text-sm">Outro valor (mín. R$ 10)<input type="number" min={10} value={amount} onChange={(e) => setAmount(+e.target.value)} className="input mt-1" /></label>
          <button disabled={amount < 10} onClick={() => { setSeed(Math.random().toString(36).slice(2, 8).toUpperCase()); setOk(false); setGen(true) }} className="btn btn-primary w-full">Gerar PIX de {brl(amount)}</button>
        </div>
      ) : <PixBox amount={amount} seed={seed} onPaid={() => { addBalance(amount); toast(`Saldo de ${brl(amount)} adicionado`); setGen(false); setOk(true) }} />}
    </div>
  )
}

export function Sobre() {
  return <div className="mx-auto max-w-2xl space-y-4"><h1 className="text-3xl font-bold">Sobre a Arthemis</h1><p className="text-muted">{SOBRE}</p></div>
}

export function Info() {
  const slug = useLocation().pathname.split('/').pop() ?? ''
  const page = PAGES[slug]
  if (!page) return <p className="py-20 text-center text-muted">Página não encontrada.</p>
  return (
    <article className="mx-auto max-w-2xl space-y-5">
      <h1 className="text-3xl font-bold">{page.title}</h1>
      <p className="text-muted">{page.intro}</p>
      {page.items.map(([h, t]) => <section key={h}><h2 className="font-semibold">{h}</h2><p className="text-sm text-muted">{t}</p></section>)}
      {page.cta && <Link to={page.cta[1]} className="btn btn-primary">{page.cta[0]}</Link>}
    </article>
  )
}

const cols: [string, [string, string][]][] = [
  ['Acesso rápido', [['Anunciar', '/p/anunciar'], ['Blog', '/p/blog'], ['Perguntas frequentes', '/p/perguntas-frequentes'], ['Categorias', '/marketplace'], ['Central de Ajuda', '/p/central-de-ajuda']]],
  ['Como funciona', [['Como funciona', '/p/como-funciona'], ['Vantagens', '/p/vantagens'], ['Tarifas e prazos', '/p/tarifas-e-prazos'], ['Formas de pagamento', '/p/formas-de-pagamento'], ['Verificador de contas', '/p/verificador']]],
  ['Institucional', [['Termos de uso', '/p/termos-de-uso'], ['Programa de recompensa', '/p/programa-de-recompensa'], ['Política de privacidade', '/p/politica-de-privacidade'], ['Política de reembolso', '/p/politica-de-reembolso'], ['Trabalhe conosco', '/p/trabalhe-conosco']]],
]
export function Footer() {
  return (
    <footer className="mt-10 border-t border-border py-10 text-sm">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 md:grid-cols-4">
        <div><p className="flex items-center gap-2 font-display text-xl"><Logo /><span><span className="text-primary">ART</span>HEMIS</span></p><p className="mt-2 text-muted">{SOBRE}</p><Link to="/sobre" className="mt-2 inline-block text-primary">Sobre nós</Link></div>
        {cols.map(([t, links]) => (
          <nav key={t} aria-label={t}><p className="mb-2 font-semibold uppercase tracking-wide">{t}</p>
            <ul className="space-y-1">{links.map(([l, to]) => <li key={l}><Link to={to} className="text-muted hover:text-foreground">{l}</Link></li>)}</ul></nav>
        ))}
      </div>
      <p className="mt-8 text-center text-muted">© 2026 Arthemis · arthemis.com. Projeto demonstrativo.</p>
    </footer>
  )
}

export function Logo() {
  return (
    <svg viewBox="0 0 24 24" className="h-7 w-7" aria-hidden="true"><path d="M12 1.5l9.5 5.5v10L12 22.5 2.5 17V7z" fill="var(--primary)" /><path d="M7.5 16.5L12 7.5l4.5 9M9.3 13.6h5.4" stroke="var(--on-primary)" strokeWidth="2.2" strokeLinecap="round" /></svg>
  )
}

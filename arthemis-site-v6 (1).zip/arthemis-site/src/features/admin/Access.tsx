import { useEffect, useState } from 'react'
import { LEGACY_ADMIN, PERMS, adminAct, can, decide, decideReq, maskCpf, readDoc, requestAdmin, review, setPerms, useAuth, useMe, type Account, type Status } from '../auth/auth'
import { toast } from '../../toast'
import { Confirm } from '../../components/Confirm'

const ST: Record<Status, [string, string]> = { pending: ['Pendente', 'badge-warning'], under_review: ['Em análise', 'badge-warning'], approved: ['Aprovado', 'badge-success'], rejected: ['Rejeitado', 'badge-danger'], suspended: ['Suspenso', 'badge-danger'] }
const DOC = { none: 'Sem documento', received: 'Recebido', approved: 'Aprovado', rejected: 'Rejeitado' }
const fmt = (d: string) => new Date(d).toLocaleString('pt-BR')
const Badge = ({ s }: { s: Status }) => <span className={`badge ${ST[s][0] ? ST[s][1] : ''}`}>{ST[s][0]}</span>
const Denied = () => <p className="alert alert-error">Você não tem permissão para acessar esta área.</p>

function Analysis({ t, back }: { t: Account; back: () => void }) {
  const [doc, setDoc] = useState<{ type: string; data: string } | null>(null)
  const [reason, setReason] = useState('')
  const [err, setErr] = useState('')
  useEffect(() => { review(t.id); setDoc(readDoc(t.id)) }, [t.id])
  const act = (ok: boolean) => { const m = decide(t.id, ok, reason); setErr(m); if (!m) toast(ok ? 'Cadastro aprovado' : 'Cadastro rejeitado') }
  const open = t.status === 'pending' || t.status === 'under_review'
  const rows: [string, string][] = [['Nome completo', t.name], ['Tipo de conta', t.role === 'seller' ? 'Vendedor' : 'Comprador'], ['CPF', t.cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4')], ['Telefone', t.phone], ['E-mail', t.email], ['Nascimento', t.birth], ['Cadastro em', fmt(t.createdAt)], ...(t.shop ? [['Loja', t.shop.name] as [string, string]] : []), ...(t.decidedBy ? [['Decidido por', `${t.decidedBy} em ${fmt(t.decidedAt ?? '')}`] as [string, string]] : []), ...(t.reason ? [['Motivo da rejeição', t.reason] as [string, string]] : [])]
  return (
    <div className="space-y-4">
      <button className="btn btn-ghost btn-sm" onClick={back}>← Voltar à lista</button>
      <div className="grid gap-4 md:grid-cols-2">
        <dl className="space-y-1 card p-4 text-sm">{rows.map(([k, v]) => <div key={k} className="flex justify-between gap-3"><dt className="text-muted">{k}</dt><dd className="text-right">{v}</dd></div>)}<div className="flex justify-between"><dt className="text-muted">Status</dt><dd><Badge s={t.status} /></dd></div></dl>
        <div className="card p-4">{doc ? (doc.type.startsWith('image') ? <img src={doc.data} alt="Documento enviado" className="max-h-96 w-full rounded-md object-contain" /> : <embed src={doc.data} type="application/pdf" className="h-96 w-full" />) : <p className="text-sm text-muted">Documento indisponível para o seu perfil.</p>}</div>
      </div>
      {open && <div className="space-y-2 card p-4">
        <input className="input" placeholder="Motivo (obrigatório para rejeitar)" value={reason} onChange={(e) => setReason(e.target.value)} />
        {err && <p role="alert" className="text-xs text-danger">{err}</p>}
        <div className="flex gap-2"><button className="btn btn-primary" onClick={() => act(true)}>Aprovar</button><button className="btn btn-ghost" onClick={() => act(false)}>Rejeitar</button></div>
      </div>}
    </div>
  )
}

export function Pending() {
  useMe()
  const all = useAuth((s) => s.users)
  const [open, setOpen] = useState('')
  if (!(can('manage_users') || can('manage_sellers') || can('manage_buyers'))) return <Denied />
  const users = all.filter((u) => u.role !== 'admin')
  const t = users.find((u) => u.id === open)
  if (t) return <Analysis t={t} back={() => setOpen('')} />
  if (!users.length) return <p className="text-muted">Nenhum cadastro recebido ainda.</p>
  return (
    <div className="card overflow-x-auto"><table className="w-full text-left text-sm">
      <thead className="text-muted"><tr><th className="p-3">Nome</th><th>Tipo</th><th>E-mail</th><th>Telefone</th><th>CPF</th><th>Cadastro</th><th>Status</th><th>Documento</th><th /></tr></thead>
      <tbody>{users.map((u) => <tr key={u.id} className="border-t border-border"><td className="p-3">{u.name}</td><td>{u.role === 'seller' ? 'Vendedor' : 'Comprador'}</td><td>{u.email}</td><td>{u.phone}</td><td>{maskCpf(u.cpf)}</td><td>{new Date(u.createdAt).toLocaleDateString('pt-BR')}</td><td><Badge s={u.status} /></td><td>{DOC[u.docStatus]}</td><td><button className="btn btn-ghost btn-sm" onClick={() => setOpen(u.id)}>Analisar</button></td></tr>)}</tbody>
    </table></div>
  )
}

export function Admins() {
  const me = useMe()
  const { users: reg, reqs } = useAuth()
  const users = [LEGACY_ADMIN, ...reg]
  const [tmp, setTmp] = useState<{ email: string; pw: string } | null>(null)
  const [f, setF] = useState({ name: '', email: '', phone: '', func: '', reason: '', perms: [] as string[] })
  const [err, setErr] = useState('')
  const [ask, setAsk] = useState<{ k: 'ok' | 'no' | 'rm'; id: string; label: string } | null>(null)
  const [why, setWhy] = useState('')
  if (!me || !can('manage_admins')) return <Denied />
  const primary = me.level === 'primary'
  const run = (m: string, ok = '') => { if (m) toast(m, 'err'); else if (ok) toast(ok) }
  const confirmAsk = async () => {
    if (!ask) return
    if (ask.k === 'rm') run(adminAct(ask.id, 'remove'), 'Administrador removido')
    else { const r = await decideReq(ask.id, ask.k === 'ok', why); if (r.err) { toast(r.err, 'err'); return } if (r.pw) setTmp({ email: ask.label, pw: r.pw }); else toast('Solicitação negada') }
    setAsk(null); setWhy('')
  }
  const send = () => { const m = requestAdmin(f); setErr(m); if (!m) { toast('Solicitação enviada ao Admin 01'); setF({ name: '', email: '', phone: '', func: '', reason: '', perms: [] }) } }
  const togglePerm = (k: string) => setF({ ...f, perms: f.perms.includes(k) ? f.perms.filter((p) => p !== k) : [...f.perms, k] })
  const name = (id: string) => users.find((u) => u.id === id)?.name ?? '—'
  return (
    <div className="space-y-6">
      {tmp && <div role="status" className="alert alert-success space-y-1"><p>Administrador {tmp.email} ativado. Senha provisória (aparece só agora): <code className="font-bold">{tmp.pw}</code></p><p className="text-xs">Entregue por um canal seguro.</p><button className="btn btn-ghost btn-sm" onClick={() => setTmp(null)}>Já anotei</button></div>}
      {ask && <Confirm title={ask.k === 'ok' ? 'Aceitar novo administrador?' : ask.k === 'no' ? 'Negar solicitação?' : 'Remover administrador?'} confirmLabel={ask.k === 'ok' ? 'Aceitar' : ask.k === 'no' ? 'Negar' : 'Remover'} onConfirm={confirmAsk} onCancel={() => { setAsk(null); setWhy('') }}>
        <p>{ask.label}</p>{ask.k === 'ok' && <p className="text-muted">A conta será ativada com as permissões solicitadas.</p>}
        {ask.k === 'no' && <input className="input mt-2" aria-label="Motivo da negativa" placeholder="Motivo da negativa" value={why} onChange={(e) => setWhy(e.target.value)} />}
      </Confirm>}
      <section className="space-y-2"><h2 className="text-lg">Administradores</h2>
        {users.filter((u) => u.role === 'admin').map((a) => (
          <div key={a.id} className="space-y-2 card p-4 text-sm">
            <div className="flex flex-wrap items-center gap-2"><b>{a.name}</b><span className="text-muted">{a.email}</span><span className="badge badge-success">{a.level === 'primary' ? 'Admin 01' : 'Secundário'}</span><Badge s={a.status} />
              {primary && a.level !== 'primary' && <span className="ml-auto flex gap-2"><button className="btn btn-ghost btn-sm" onClick={() => run(adminAct(a.id, a.status === 'suspended' ? 'reactivate' : 'suspend'))}>{a.status === 'suspended' ? 'Reativar' : 'Suspender'}</button><button className="btn btn-ghost btn-sm" onClick={() => setAsk({ k: 'rm', id: a.id, label: a.name })}>Remover</button></span>}</div>
            <div className="flex flex-wrap gap-1">{PERMS.map(([k, l]) => { const on = a.level === 'primary' || a.perms.includes(k); return <button key={k} type="button" disabled={!primary || a.level === 'primary'} aria-pressed={on} onClick={() => run(setPerms(a.id, on ? a.perms.filter((p) => p !== k) : [...a.perms, k]))} className={`chip h-7 px-3 text-xs ${on ? 'chip-active' : ''}`}>{l}</button> })}</div>
          </div>))}
      </section>
      <section className="space-y-2"><h2 className="text-lg">Solicitações de administradores</h2>
        {!reqs.length && <p className="text-sm text-muted">Nenhuma solicitação.</p>}
        {reqs.map((r) => (
          <div key={r.id} className="space-y-1 card p-4 text-sm">
            <p><b>{r.name}</b> · {r.email} · {r.func} <span className={`badge ${r.status === 'pending' ? 'badge-warning' : r.status === 'approved' ? 'badge-success' : 'badge-danger'}`}>{{ pending: 'Pendente', approved: 'Aprovada', rejected: 'Negada' }[r.status]}</span></p>
            <p className="text-muted">Solicitado por {name(r.requesterId)} em {fmt(r.createdAt)}. Motivo: {r.reason}</p>
            <p className="text-muted">Permissões: {r.perms.map((p) => PERMS.find(([k]) => k === p)?.[1]).join(', ') || 'nenhuma'}</p>
            {r.decidedBy && <p className="text-muted">Decidida por {r.decidedBy} em {fmt(r.decidedAt ?? '')}{r.decisionReason ? `. Motivo: ${r.decisionReason}` : ''}</p>}
            {primary && r.status === 'pending' && <div className="flex gap-2 pt-1"><button className="btn btn-primary btn-sm" onClick={() => setAsk({ k: 'ok', id: r.id, label: r.email })}>Aceitar</button><button className="btn btn-ghost btn-sm" onClick={() => setAsk({ k: 'no', id: r.id, label: r.email })}>Negar</button></div>}
          </div>))}
      </section>
      <section className="space-y-2 card p-4"><h2 className="text-lg">Solicitar novo administrador</h2>
        <p className="text-xs text-muted">A pessoa só ganha acesso depois que o Admin 01 aceitar.</p>
        <div className="grid gap-2 sm:grid-cols-2">{([['name', 'Nome completo'], ['email', 'E-mail'], ['phone', 'Telefone (opcional)'], ['func', 'Função']] as const).map(([k, l]) => <input key={k} aria-label={l} placeholder={l} className="input" value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} />)}</div>
        <textarea aria-label="Motivo da solicitação" placeholder="Motivo da solicitação" className="input h-20 py-2" value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} />
        <div className="flex flex-wrap gap-1">{PERMS.map(([k, l]) => <button key={k} type="button" aria-pressed={f.perms.includes(k)} onClick={() => togglePerm(k)} className={`chip h-7 px-3 text-xs ${f.perms.includes(k) ? 'chip-active' : ''}`}>{l}</button>)}</div>
        {err && <p role="alert" className="text-xs text-danger">{err}</p>}
        <button className="btn btn-primary" onClick={send}>Enviar solicitação</button>
      </section>
    </div>
  )
}

export function Audit() {
  useMe()
  const logs = useAuth((s) => s.logs)
  if (!can('manage_admins')) return <Denied />
  if (!logs.length) return <p className="text-muted">Nenhuma ação registrada ainda.</p>
  return <div className="card overflow-x-auto"><table className="w-full text-left text-sm"><thead className="text-muted"><tr><th className="p-3">Data</th><th>Responsável</th><th>Ação</th><th>Entidade</th><th>ID</th><th>Motivo</th></tr></thead>
    <tbody>{logs.map((l) => <tr key={l.id} className="border-t border-border"><td className="p-3">{fmt(l.at)}</td><td>{l.actor}</td><td>{l.action}</td><td>{l.entity}</td><td>{l.entityId}</td><td>{l.reason ?? '—'}</td></tr>)}</tbody></table></div>
}

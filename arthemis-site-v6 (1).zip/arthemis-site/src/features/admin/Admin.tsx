import { useState } from 'react'
import { Navigate } from 'react-router-dom'
import { useStore } from '../../store'
import { Finance } from './Finance'
import { People, ReviewsAdmin } from './Manage'
import { AdminEvents } from '../events/AdminEvents'
import { AdminTickets } from '../tickets/Tickets'
import { can, useMe } from '../auth/auth'
import { Admins, Audit, Pending } from './Access'
const SECTIONS = ['Dashboard', 'Financeiro', 'Eventos', 'Usuários', 'Vendedores', 'Produtos', 'Categorias', 'Pedidos', 'Pagamentos', 'Cupons', 'Denúncias', 'Disputas', 'Tickets', 'Avaliações', 'Relatórios', 'Configurações']
// Cada área do Admin exige uma permissão (Admin 01 tem todas). As ações também são conferidas no store.
const PERM_OF: Record<string, string> = { Financeiro: 'manage_payments', Pagamentos: 'manage_payments', Eventos: 'manage_events', Disputas: 'manage_events', Usuários: 'manage_users', Vendedores: 'manage_sellers', Produtos: 'manage_products', Pedidos: 'manage_orders', Denúncias: 'manage_reports', Tickets: 'manage_tickets', Avaliações: 'manage_reviews', Configurações: 'manage_settings', Administradores: 'manage_admins', Auditoria: 'manage_admins' }
const allowed = (s: string) => (s === 'Cadastros pendentes' ? can('manage_users') || can('manage_sellers') || can('manage_buyers') : !PERM_OF[s] || can(PERM_OF[s]))
const STATUS: [string, string][] = [['Ativo', 'badge-success'], ['Pendente', 'badge-warning'], ['Bloqueado', 'badge-danger']]
const KPIS: [string, string][] = [['Usuários', '12.480'], ['Vendedores', '1.204'], ['Pedidos hoje', '382'], ['Disputas abertas', '7']]
export function Admin() {
  const role = useStore((s) => s.role)
  const me = useMe()
  const [sec, setSec] = useState(SECTIONS[0])
  if (role !== 'admin' || !me) return <Navigate to="/" replace />
  const secs = [...SECTIONS, 'Cadastros pendentes', 'Administradores', 'Auditoria'].filter(allowed)
  return (
    <div className="grid gap-5 md:grid-cols-[220px_1fr]">
      <nav aria-label="Administração" className="flex gap-2 overflow-x-auto md:flex-col">
        {secs.map((s) => <button key={s} onClick={() => setSec(s)} className={`chip shrink-0 ${sec === s ? 'chip-active' : ''}`}>{s}</button>)}
      </nav>
      <section className="space-y-4">
        <h1 className="section-title">{sec}</h1>
        {!allowed(sec) ? <p className="alert alert-error">Você não tem permissão para acessar esta área.</p> : sec === 'Cadastros pendentes' ? <Pending /> : sec === 'Administradores' ? <Admins /> : sec === 'Auditoria' ? <Audit /> : sec === 'Financeiro' ? <Finance /> : sec === 'Eventos' ? <AdminEvents /> : sec === 'Usuários' ? <People kind="users" /> : sec === 'Vendedores' ? <People kind="sellers" /> : sec === 'Avaliações' ? <ReviewsAdmin /> : sec === 'Tickets' ? <AdminTickets kind="ticket" /> : sec === 'Denúncias' ? <AdminTickets kind="denuncia" /> : sec === 'Dashboard' ? (
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">{KPIS.map(([k, v]) => <div key={k} className="card p-4"><p className="text-xs text-muted">{k}</p><p className="font-display text-2xl">{v}</p></div>)}</div>
        ) : (
          <div className="card overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="text-muted"><tr><th className="p-3">Registro</th><th>Status</th><th>Data</th><th /></tr></thead>
              <tbody>{Array.from({ length: 6 }, (_, i) => (
                <tr key={i} className="border-t border-border"><td className="p-3">{sec} #{1001 + i}</td><td><span className={`badge ${STATUS[i % 3][1]}`}>{STATUS[i % 3][0]}</span></td><td>0{i + 1}/10/2026</td><td><button className="btn btn-ghost btn-sm">Ver</button></td></tr>
              ))}</tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  )
}

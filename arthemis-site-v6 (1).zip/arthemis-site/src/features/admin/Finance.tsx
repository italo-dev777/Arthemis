import { brl, products } from '../../data'
import { DEFAULT_FEE, sales } from '../../finance'
import { useStore } from '../../store'

export function Finance() {
  const { orders, received, markReceived, fees, setFee, setAff } = useStore()
  const rows = sales(orders).map((s) => {
    const pct = fees.platform[s.seller] ?? DEFAULT_FEE
    const fee = (s.value * pct) / 100
    const aff = s.ref ? (s.value * fees.aff) / 100 : 0
    return { ...s, pct, fee, aff, platform: fee - aff, net: s.value - fee, done: received.includes(s.id) }
  })
  type R = (typeof rows)[number]
  const sum = (f: (r: R) => number, done?: boolean) => rows.filter((r) => done === undefined || r.done === done).reduce((a, r) => a + f(r), 0)
  const pending = rows.filter((r) => !r.done).map((r) => r.id)
  const kpis: [string, string][] = [['Total vendido', brl(sum((r) => r.value))], ['A receber', brl(sum((r) => r.value, false))], ['Recebido', brl(sum((r) => r.value, true))],
    ['Receita da plataforma', brl(sum((r) => r.platform))], ['Comissões de afiliados', brl(sum((r) => r.aff))], ['Repasse a vendedores', brl(sum((r) => r.net))]]
  const sellers = [...new Set(products.map((p) => p.seller))]
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">{kpis.map(([k, v]) => <div key={k} className="card p-4"><p className="text-xs text-muted">{k}</p><p className="font-display text-2xl">{v}</p></div>)}</div>
      <section className="card space-y-3 p-4">
        <h2 className="text-lg">Porcentagens</h2>
        <label className="flex items-center gap-2 text-sm">Comissão do afiliado (% da venda)<input type="number" min={0} max={100} className="input h-9 w-20 px-2" value={fees.aff} onChange={(e) => setAff(+e.target.value)} /></label>
        <div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="text-muted"><tr><th className="py-2">Vendedor</th><th>% da plataforma</th><th>Vendas</th><th>Total vendido</th><th>Taxa recebida</th></tr></thead>
          <tbody>{sellers.map((s) => { const r = rows.filter((x) => x.seller === s); return (
            <tr key={s} className="border-t border-border"><td className="py-2">@{s}</td><td><input type="number" min={0} max={100} className="input h-9 w-20 px-2" value={fees.platform[s] ?? DEFAULT_FEE} onChange={(e) => setFee(s, +e.target.value)} /></td><td>{r.length}</td><td>{brl(r.reduce((a, x) => a + x.value, 0))}</td><td>{brl(r.reduce((a, x) => a + x.fee, 0))}</td></tr>) })}</tbody></table></div>
        <p className="text-xs text-muted">A comissão do afiliado sai da parte da plataforma. Os percentuais iniciais (10% por venda e 5% de afiliado) são valores de exemplo: ajuste conforme a sua regra.</p>
      </section>
      <section className="space-y-2">
        <div className="flex items-center justify-between"><h2 className="text-lg">Vendas e recebimentos</h2><button className="btn btn-primary btn-sm" disabled={!pending.length} onClick={() => markReceived(pending)}>Confirmar todos ({pending.length})</button></div>
        <div className="card overflow-x-auto"><table className="w-full min-w-[900px] text-left text-sm">
          <thead className="text-muted"><tr><th className="p-3">Venda</th><th>Produto</th><th>Vendedor</th><th>Origem</th><th>Valor</th><th>%</th><th>Plataforma</th><th>Afiliado</th><th>Líquido vendedor</th><th>Status</th><th /></tr></thead>
          <tbody>{rows.map((r) => (
            <tr key={r.id} className="border-t border-border"><td className="p-3">{r.demo ? <>{r.id} <span className="badge badge-warning">exemplo</span></> : r.id.split('-').slice(0, 2).join('-')}</td><td>{r.name}</td><td>@{r.seller}</td><td>{r.ref ? `Afiliado ${r.ref}` : 'Direta'}</td><td>{brl(r.value)}</td><td>{r.pct}%</td><td>{brl(r.platform)}</td><td>{brl(r.aff)}</td><td>{brl(r.net)}</td>
              <td><span className={`badge ${r.done ? 'badge-success' : 'badge-warning'}`}>{r.done ? 'Recebido' : 'A receber'}</span></td>
              <td className="pr-3"><button className="btn btn-ghost btn-sm" disabled={r.done} onClick={() => markReceived([r.id])}>Confirmar</button></td></tr>))}</tbody></table></div>
      </section>
    </div>
  )
}

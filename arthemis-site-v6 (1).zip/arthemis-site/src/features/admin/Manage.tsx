import { useState } from 'react'
import { Confirm } from '../../components/Confirm'
import { products } from '../../data'
import { SELLERS_INFO, USERS, fmtDay, type Person } from '../../people'
import { useStore } from '../../store'
import { useAuth } from '../auth/auth'

export function People({ kind }: { kind: 'users' | 'sellers' }) {
  const { removed, removeEntity, restoreEntity, email } = useStore()
  const [pick, setPick] = useState<Person | null>(null)
  const reg = useAuth((s) => s.users)
  // Contas criadas pelo cadastro entram na lista junto com os exemplos (só depois de aprovadas)
  const signed: Person[] = reg.filter((u) => u.role === (kind === 'users' ? 'buyer' : 'seller') && u.status === 'approved').map((u) => ({ id: u.email, name: u.name, email: u.email, type: kind === 'users' ? 'Comprador' : 'Vendedor', since: u.createdAt.slice(0, 10) }))
  const rows = [...(kind === 'users' ? USERS : SELLERS_INFO), ...signed]
  const word = kind === 'users' ? 'usuário' : 'vendedor'
  return (
    <>
      <div className="card overflow-x-auto">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead className="text-muted"><tr><th className="p-3">Nome</th><th>E-mail</th><th>Tipo de conta</th><th>Cadastro</th>{kind === 'sellers' && <th>Produtos</th>}<th>Status</th><th /></tr></thead>
          <tbody>{rows.map((p) => {
            const gone = removed[kind].includes(p.id), self = p.id === email
            return (
              <tr key={p.id} className={`border-t border-border ${gone ? 'opacity-50' : ''}`}>
                <td className="p-3">{p.name}{self && ' (você)'}</td><td>{p.email}</td><td>{p.type}</td><td>{fmtDay(p.since)}</td>
                {kind === 'sellers' && <td>{products.filter((x) => x.seller === p.id).length}</td>}
                <td><span className={`badge ${gone ? 'badge-danger' : 'badge-success'}`}>{gone ? 'Removido' : 'Ativo'}</span></td>
                <td className="pr-3 text-right">{gone
                  ? <button className="btn btn-ghost btn-sm" onClick={() => restoreEntity(kind, p.id)}>Restaurar</button>
                  : <button className="btn btn-ghost btn-sm" disabled={self} title={self ? 'Você não pode remover a própria conta' : ''} onClick={() => setPick(p)}>Remover</button>}</td>
              </tr>
            )
          })}</tbody>
        </table>
      </div>
      <p className="text-xs text-muted">Inclui cadastros de exemplo. A remoção é reversível pelo botão Restaurar.</p>
      {pick && (
        <Confirm title={`Remover ${word}?`} onCancel={() => setPick(null)} onConfirm={() => { removeEntity(kind, pick.id); setPick(null) }}>
          <p><b>Nome:</b> {pick.name}</p><p><b>E-mail:</b> {pick.email}</p><p><b>Tipo de conta:</b> {pick.type}</p><p><b>Cadastro:</b> {fmtDay(pick.since)}</p>
          <p className="pt-2 text-muted">{kind === 'sellers' ? 'Os produtos deste vendedor deixarão de aparecer no site.' : 'Este usuário não conseguirá mais entrar na conta.'}</p>
        </Confirm>
      )}
    </>
  )
}

export function ReviewsAdmin() {
  const { reviews, removeReview } = useStore()
  const [pick, setPick] = useState<(typeof reviews)[number] | null>(null)
  if (!reviews.length) return <p className="card p-8 text-center text-muted">Nenhuma avaliação publicada ainda. As avaliações feitas por compradores aparecem aqui.</p>
  const prod = (slug: string) => products.find((p) => p.slug === slug)
  return (
    <>
      <div className="space-y-3">{reviews.map((r) => (
        <div key={r.slug + r.user + r.date} className="card flex flex-wrap items-start justify-between gap-3 p-4">
          <div className="text-sm">
            <p className="font-semibold">{prod(r.slug)?.name ?? r.slug} <span className="font-normal text-muted">· vendedor @{prod(r.slug)?.seller ?? '—'}</span></p>
            <p className="text-muted">Avaliado por @{r.user} · <span className="text-warning">{'★'.repeat(r.rating)}</span> {r.rating}/5 · {new Date(r.date).toLocaleDateString('pt-BR')}</p><p className="mt-1">{r.text}</p>
          </div>
          <button className="btn btn-ghost btn-sm" onClick={() => setPick(r)}>Remover</button>
        </div>
      ))}</div>
      {pick && (
        <Confirm title="Remover avaliação?" onCancel={() => setPick(null)} onConfirm={() => { removeReview(pick); setPick(null) }}>
          <p><b>Produto:</b> {prod(pick.slug)?.name ?? pick.slug}</p><p><b>Vendedor:</b> @{prod(pick.slug)?.seller ?? '—'}</p><p><b>Usuário:</b> @{pick.user}</p><p><b>Nota:</b> {pick.rating}/5</p><p><b>Comentário:</b> {pick.text}</p>
        </Confirm>
      )}
    </>
  )
}

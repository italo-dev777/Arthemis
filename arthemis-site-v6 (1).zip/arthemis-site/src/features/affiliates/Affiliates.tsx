import { useState } from 'react'
import { Navigate } from 'react-router-dom'
import { Copy } from 'lucide-react'
import { brl } from '../../data'
import { sales } from '../../finance'
import { useStore } from '../../store'
import { toast } from '../../toast'
import { Withdraw } from '../wallet/Withdraw'

const TABS = [['link', 'Meu link'], ['sacar', 'Sacar para PIX'], ['hist', 'Histórico de saques']] as const
export function Affiliates() {
  const { user, orders, withdrawals, fees } = useStore()
  const [tab, setTab] = useState<(typeof TABS)[number][0]>('sacar')
  if (!user) return <Navigate to="/login" replace />
  const code = user.toUpperCase()
  const link = `${window.location.origin}/?ref=${code}`
  const mine = sales(orders).filter((s) => s.ref === code)
  const commission = mine.reduce((a, s) => a + (s.value * fees.aff) / 100, 0)
  const mineW = withdrawals.filter((w) => w.source === 'buyer')
  return (
    <div className="space-y-5">
      <div><p className="eyebrow">Afiliados · Compradores</p><h1 className="text-3xl">Programa de afiliados</h1></div>
      <nav className="flex flex-wrap gap-2" aria-label="Seções">{TABS.map(([id, t]) => <button key={id} onClick={() => setTab(id)} className={`chip ${tab === id ? 'chip-active' : ''}`}>{t}</button>)}</nav>
      {tab === 'link' && (
        <section className="card max-w-xl space-y-3 p-5">
          <p className="text-sm text-muted">Compartilhe seu link. Compras feitas por ele rendem {fees.aff}% do valor da venda.</p>
          <code className="block break-all rounded-md bg-card-hover p-2 text-sm">{link}</code>
          <button className="btn btn-ghost btn-sm" onClick={() => { navigator.clipboard?.writeText(link); toast('Link copiado') }}><Copy className="h-4 w-4" />Copiar link</button>
          <div className="grid grid-cols-2 gap-3"><div className="card p-4"><p className="text-xs text-muted">Vendas pelo seu link</p><p className="text-2xl font-bold">{mine.length}</p></div><div className="card p-4"><p className="text-xs text-muted">Comissão gerada</p><p className="text-2xl font-bold text-primary">{brl(commission)}</p></div></div>
        </section>
      )}
      {tab === 'sacar' && <Withdraw source="buyer" />}
      {tab === 'hist' && (mineW.length ? (
        <div className="card overflow-x-auto"><table className="w-full text-left text-sm"><thead className="text-muted"><tr><th className="p-3">Código</th><th>Data</th><th>Chave</th><th>Valor</th></tr></thead>
          <tbody>{mineW.map((w) => <tr key={w.id} className="border-t border-border"><td className="p-3">{w.id}</td><td>{new Date(w.date).toLocaleDateString('pt-BR')}</td><td>{w.key}</td><td>{brl(w.amount)}</td></tr>)}</tbody></table></div>
      ) : <p className="py-10 text-center text-muted">Você ainda não fez nenhum saque.</p>)}
    </div>
  )
}

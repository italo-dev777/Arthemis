import { useState, type ReactNode } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { Eye, EyeOff } from 'lucide-react'
import { PW, adult, checkFile, dg, pwOk, register, useAuth, validCpf, validEmail, validPhone } from './auth'

const L = ['Tipo de conta', 'Dados pessoais', 'Contato', 'Documento', 'Senha', 'Termos', 'Confirmação']
const Field = ({ label, err, children }: { label: string; err?: string; children: ReactNode }) => <label className="block text-sm">{label}{children}{err && <span role="alert" className="mt-1 block text-xs text-danger">{err}</span>}</label>

function PwFields({ d, set, err }: { d: { pw: string; pw2: string }; set: (k: string, v: string) => void; err: Record<string, string> }) {
  const [show, setShow] = useState(false)
  const n = PW.filter(([, t]) => t(d.pw)).length
  return (
    <div className="space-y-3">
      <Field label="Senha" err={err.pw}>
        <span className="relative block"><input className="input pr-10" type={show ? 'text' : 'password'} autoComplete="new-password" value={d.pw} onChange={(e) => set('pw', e.target.value)} aria-invalid={!!err.pw} />
          <button type="button" aria-label={show ? 'Ocultar senha' : 'Mostrar senha'} className="absolute right-3 top-3 text-muted" onClick={() => setShow(!show)}>{show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button></span>
      </Field>
      <div aria-label="Força da senha"><div className="h-1.5 rounded-full bg-border"><div className={`h-full rounded-full ${n < 3 ? 'bg-danger' : n < 5 ? 'bg-warning' : 'bg-success'}`} style={{ width: `${n * 20}%` }} /></div>
        <p className="mt-1 text-xs text-muted">Força: {['muito fraca', 'fraca', 'fraca', 'média', 'boa', 'forte'][n]}</p></div>
      <ul className="grid grid-cols-2 gap-1 text-xs">{PW.map(([l, t]) => <li key={l} className={t(d.pw) ? 'text-success' : 'text-muted'}>{t(d.pw) ? '✓' : '○'} {l}</li>)}</ul>
      <Field label="Confirmar senha" err={err.pw2}><input className="input" type={show ? 'text' : 'password'} autoComplete="new-password" value={d.pw2} onChange={(e) => set('pw2', e.target.value)} aria-invalid={!!err.pw2} /></Field>
    </div>
  )
}

export function Register() {
  const [sp] = useSearchParams()
  const [s, setS] = useState(0)
  const [d, setD] = useState({ role: (sp.get('tipo') === 'vendedor' ? 'seller' : '') as '' | 'buyer' | 'seller', name: '', cpf: '', birth: '', shop: '', desc: '', phone: '', email: '', pw: '', pw2: '', terms: false, priv: false })
  const [file, setFile] = useState<File | null>(null)
  const [err, setErr] = useState<Record<string, string>>({})
  const [busy, setBusy] = useState(false)
  const [done, setDone] = useState(false)
  const set = (k: string, v: string | boolean) => setD((x) => ({ ...x, [k]: v }))
  const bind = (k: 'name' | 'cpf' | 'birth' | 'shop' | 'desc' | 'phone' | 'email') => ({ value: d[k], onChange: (e: { target: { value: string } }) => set(k, e.target.value), 'aria-invalid': !!err[k] })
  async function check(i: number) {
    const e: Record<string, string> = {}, users = useAuth.getState().users
    if (i === 0 && !d.role) e.role = 'Escolha o tipo de conta.'
    if (i === 1) {
      if (d.name.trim().split(/\s+/).length < 2) e.name = 'Informe nome e sobrenome.'
      if (!validCpf(d.cpf)) e.cpf = 'CPF inválido.'; else if (users.some((u) => u.cpf === dg(d.cpf))) e.cpf = 'Já existe uma conta com este CPF.'
      if (!adult(d.birth)) e.birth = 'É preciso ter 18 anos ou mais.'
      if (d.role === 'seller' && !d.shop.trim()) e.shop = 'Informe o nome da loja.'
    }
    if (i === 2) {
      if (!validPhone(d.phone)) e.phone = 'Telefone inválido. Use DDD + número.'
      if (!validEmail(d.email)) e.email = 'E-mail inválido.'; else if (users.some((u) => u.email === d.email.trim().toLowerCase())) e.email = 'Já existe uma conta com este e-mail.'
    }
    if (i === 3) { const m = await checkFile(file); if (m) e.file = m }
    if (i === 4) { if (!pwOk(d.pw)) e.pw = 'A senha não atende a todos os requisitos.'; if (d.pw !== d.pw2) e.pw2 = 'As senhas não são iguais.' }
    if (i === 5 && !(d.terms && d.priv)) e.terms = 'Aceite os Termos de Uso e a Política de Privacidade.'
    return e
  }
  const next = async () => { const e = await check(s); setErr(e); if (!Object.keys(e).length) setS(s + 1) }
  const send = async () => {
    if (d.role === '') return
    setBusy(true)
    const m = await register({ role: d.role, name: d.name, cpf: d.cpf, birth: d.birth, phone: d.phone, email: d.email, pw: d.pw, file, shop: d.role === 'seller' ? { name: d.shop, description: d.desc } : undefined })
    setBusy(false)
    if (m) setErr({ submit: m }); else setDone(true)
  }
  if (done) return <div className="mx-auto max-w-md space-y-3 card p-8 text-center"><p className="text-4xl">📨</p><h1 className="text-2xl">Cadastro enviado</h1><p className="text-sm text-muted">Seu cadastro foi recebido e está aguardando aprovação. Você poderá entrar assim que a análise terminar.</p><Link to="/" className="btn btn-primary">Voltar ao início</Link></div>
  const type = (r: 'buyer' | 'seller', t: string, sub: string) => <button type="button" onClick={() => set('role', r)} className={`card p-5 text-left ${d.role === r ? 'border-primary' : ''}`} aria-pressed={d.role === r}><p className="font-semibold">{t}</p><p className="text-sm text-muted">{sub}</p></button>
  return (
    <div className="mx-auto max-w-lg space-y-4">
      <h1 className="text-2xl font-bold">Criar conta</h1>
      <p className="text-sm text-muted" aria-live="polite">Etapa {s + 1} de {L.length}: {L[s]}</p>
      <div className="h-1.5 rounded-full bg-border"><div className="h-full rounded-full bg-primary transition-all" style={{ width: `${((s + 1) / L.length) * 100}%` }} /></div>
      <div className="space-y-3 card p-5">
        {s === 0 && <><div className="grid gap-3 sm:grid-cols-2">{type('buyer', 'Comprador', 'Compre produtos digitais com proteção.')}{type('seller', 'Vendedor', 'Anuncie e receba pelas suas vendas.')}</div>{err.role && <p role="alert" className="text-xs text-danger">{err.role}</p>}</>}
        {s === 1 && <><Field label="Nome completo" err={err.name}><input className="input" autoComplete="name" {...bind('name')} /></Field><Field label="CPF" err={err.cpf}><input className="input" inputMode="numeric" placeholder="000.000.000-00" {...bind('cpf')} /></Field><Field label="Data de nascimento" err={err.birth}><input className="input" type="date" {...bind('birth')} /></Field>
          {d.role === 'seller' && <><Field label="Nome da loja" err={err.shop}><input className="input" {...bind('shop')} /></Field><Field label="Descrição da loja (opcional)"><textarea className="input h-20 py-2" {...bind('desc')} /></Field></>}</>}
        {s === 2 && <><Field label="Telefone" err={err.phone}><input className="input" type="tel" inputMode="tel" autoComplete="tel" placeholder="(11) 91234-5678" {...bind('phone')} /></Field><Field label={d.role === 'seller' ? 'E-mail de acesso' : 'E-mail'} err={err.email}><input className="input" type="email" autoComplete="email" {...bind('email')} /></Field></>}
        {s === 3 && <><Field label="Foto do documento de identificação (JPG, PNG ou PDF, até 2 MB)" err={err.file}><input className="input h-auto py-2" type="file" accept=".jpg,.jpeg,.png,.pdf,image/jpeg,image/png,application/pdf" onChange={(e) => setFile(e.target.files?.[0] ?? null)} aria-invalid={!!err.file} /></Field>{file && <p className="text-xs text-muted">Selecionado: {file.name}</p>}<p className="text-xs text-muted">O documento só pode ser aberto por administradores autorizados a analisar cadastros.</p></>}
        {s === 4 && <PwFields d={d} set={set} err={err} />}
        {s === 5 && <><label className="flex gap-2 text-sm"><input type="checkbox" checked={d.terms} onChange={(e) => set('terms', e.target.checked)} />Li e aceito os <Link to="/p/termos-de-uso" target="_blank" className="text-primary">Termos de Uso</Link>.</label><label className="flex gap-2 text-sm"><input type="checkbox" checked={d.priv} onChange={(e) => set('priv', e.target.checked)} />Li e aceito a <Link to="/p/politica-de-privacidade" target="_blank" className="text-primary">Política de Privacidade</Link>.</label>{err.terms && <p role="alert" className="text-xs text-danger">{err.terms}</p>}</>}
        {s === 6 && <dl className="space-y-1 text-sm">{([['Tipo', d.role === 'seller' ? 'Vendedor' : 'Comprador'], ['Nome', d.name], ['CPF', '***.***.***-' + dg(d.cpf).slice(-2)], ['Telefone', d.phone], ['E-mail', d.email], ['Documento', file?.name ?? '']] as [string, string][]).concat(d.role === 'seller' ? [['Loja', d.shop]] : []).map(([k, v]) => <div key={k} className="flex justify-between gap-3"><dt className="text-muted">{k}</dt><dd>{v}</dd></div>)}</dl>}
        {err.submit && <p role="alert" className="alert alert-error">{err.submit}</p>}
      </div>
      <div className="flex gap-2">
        {s > 0 && <button className="btn btn-ghost" onClick={() => { setErr({}); setS(s - 1) }} disabled={busy}>Voltar</button>}
        {s < 6 ? <button className="btn btn-primary flex-1" onClick={next}>Continuar</button> : <button className="btn btn-primary flex-1" onClick={send} disabled={busy} aria-busy={busy}>Enviar cadastro</button>}
      </div>
      <p className="text-center text-sm text-muted">Já tem conta? <Link to="/login" className="text-primary">Entrar</Link></p>
    </div>
  )
}

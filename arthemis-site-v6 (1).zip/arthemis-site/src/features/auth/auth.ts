import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { useStore, type Role } from '../../store'

export type Status = 'pending' | 'under_review' | 'approved' | 'rejected' | 'suspended'
export const PERMS: [string, string][] = [['manage_users', 'Usuários'], ['manage_sellers', 'Vendedores'], ['manage_buyers', 'Compradores'], ['manage_admins', 'Administradores'], ['manage_reviews', 'Avaliações'], ['manage_tickets', 'Tickets'], ['manage_reports', 'Denúncias'], ['manage_events', 'Eventos'], ['manage_products', 'Produtos'], ['manage_orders', 'Pedidos'], ['manage_payments', 'Pagamentos'], ['manage_settings', 'Configurações']]
export interface Account { id: string; name: string; email: string; phone: string; cpf: string; birth: string; role: Role; level?: 'primary' | 'secondary'; func?: string; perms: string[]; status: Status; docStatus: 'none' | 'received' | 'approved' | 'rejected'; salt: string; hash: string; shop?: { name: string; description: string }; createdAt: string; decidedAt?: string; decidedBy?: string; reason?: string }
export interface AdminReq { id: string; requesterId: string; name: string; email: string; phone: string; func: string; perms: string[]; reason: string; status: 'pending' | 'approved' | 'rejected'; createdAt: string; decidedAt?: string; decidedBy?: string; decisionReason?: string }
export interface Log { id: string; actor: string; action: string; entity: string; entityId: string; reason?: string; at: string }
interface S { users: Account[]; reqs: AdminReq[]; logs: Log[] }

export const useAuth = create<S>()(persist(() => ({ users: [], reqs: [], logs: [] }), { name: 'arthemis-auth' }))
// Documentos ficam em chave separada e só são lidos por readDoc(), que confere a permissão. Em demo, continuam no navegador: veja o README.
const docs = create<{ d: Record<string, { type: string; data: string }> }>()(persist(() => ({ d: {} }), { name: 'arthemis-docs' }))
const st = useAuth.getState
const put = useAuth.setState
const now = () => new Date().toISOString()
const hex = (b: Uint8Array) => Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('')
const rnd = (n = 8) => hex(crypto.getRandomValues(new Uint8Array(n)))
export const hashPw = async (pw: string, salt: string) => {
  const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(pw), 'PBKDF2', false, ['deriveBits'])
  return hex(new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: new TextEncoder().encode(salt), iterations: 210000 }, k, 256)))
}

export const dg = (s: string) => s.replace(/\D/g, '')
export const maskCpf = (c: string) => (c ? `***.***.***-${dg(c).slice(-2)}` : '—')
export function validCpf(v: string) {
  const c = dg(v)
  if (c.length !== 11 || /^(\d)\1+$/.test(c)) return false
  for (const n of [9, 10]) { let s = 0; for (let i = 0; i < n; i++) s += +c[i] * (n + 1 - i); if (((s * 10) % 11) % 10 !== +c[n]) return false }
  return true
}
export const validPhone = (v: string) => /^[1-9]\d(9\d{8}|[2-5]\d{7})$/.test(dg(v))
export const validEmail = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim())
export const adult = (b: string) => { const d = new Date(b), t = new Date(); t.setFullYear(t.getFullYear() - 18); return !isNaN(+d) && d <= t }
export const PW: [string, (p: string) => boolean][] = [['8+ caracteres', (p) => p.length >= 8], ['Letra maiúscula', (p) => /[A-Z]/.test(p)], ['Letra minúscula', (p) => /[a-z]/.test(p)], ['Número', (p) => /\d/.test(p)], ['Caractere especial', (p) => /[^A-Za-z0-9]/.test(p)]]
export const pwOk = (p: string) => PW.every(([, t]) => t(p))
export async function checkFile(f: File | null) {
  if (!f) return 'Envie a foto do documento.'
  if (f.size > 2 * 1024 * 1024) return 'O arquivo deve ter no máximo 2 MB.'
  const h = new Uint8Array(await f.slice(0, 4).arrayBuffer()).join(',')
  const ok = h.startsWith('255,216,255') || h === '137,80,78,71' || h === '37,80,68,70'
  return ok && /\.(jpe?g|png|pdf)$/i.test(f.name) ? '' : 'Formato inválido. Use JPG, PNG ou PDF.'
}

// Admin 01 = a conta de administrador que já existe em ACCOUNTS (src/store). Ela não é criada nem editada por aqui.
const ALL = PERMS.map(([k]) => k)
export const LEGACY_ADMIN: Account = { id: 'admin-01', name: 'Admin', email: 'admin@arthemis.com', phone: '', cpf: '', birth: '', role: 'admin', level: 'primary', perms: ALL, status: 'approved', docStatus: 'approved', salt: '', hash: '', createdAt: '2026-01-01T00:00:00.000Z' }
// A conta logada é sempre derivada do store (e-mail + função) e conferida de novo na lista de contas aprovadas
const find = (users: Account[], email: string | null, role: Role) => (email === LEGACY_ADMIN.email && role === 'admin' ? LEGACY_ADMIN : users.find((u) => u.email === email && u.role === role && u.status === 'approved'))
export const me = () => { const s = useStore.getState(); return find(st().users, s.email, s.role) }
export const useMe = () => { const e = useStore((s) => s.email), r = useStore((s) => s.role); return useAuth((s) => find(s.users, e, r)) }
export const can = (p: string) => { const u = me(); return !!u && u.role === 'admin' && (u.level === 'primary' || u.perms.includes(p)) }
const canFor = (t: Account) => can('manage_users') || can(t.role === 'seller' ? 'manage_sellers' : 'manage_buyers')
const patch = (id: string, p: Partial<Account>) => put((s) => ({ users: s.users.map((x) => (x.id === id ? { ...x, ...p } : x)) }))
const log = (action: string, entity: string, entityId: string, reason?: string) => {
  const u = me()
  put((s) => ({ logs: [{ id: rnd(6), actor: u ? `${u.name} (${u.level === 'primary' ? 'Admin 01' : 'Admin'})` : 'sistema', action, entity, entityId, reason, at: now() }, ...s.logs].slice(0, 500) }))
}

type Reg = { role: 'buyer' | 'seller'; name: string; cpf: string; birth: string; phone: string; email: string; pw: string; shop?: { name: string; description: string }; file: File | null }
export async function register(f: Reg): Promise<string> {
  const email = f.email.trim().toLowerCase(), cpf = dg(f.cpf)
  if (f.name.trim().split(/\s+/).length < 2 || !validCpf(cpf) || !validPhone(f.phone) || !validEmail(email) || !adult(f.birth) || !pwOk(f.pw)) return 'Dados inválidos. Revise o cadastro.'
  if (f.role === 'seller' && !f.shop?.name.trim()) return 'Informe o nome da loja.'
  const fe = await checkFile(f.file)
  if (fe) return fe
  if (st().users.some((u) => u.email === email)) return 'Já existe uma conta com este e-mail.'
  if (st().users.some((u) => u.cpf === cpf)) return 'Já existe uma conta com este CPF.'
  const file = f.file as File, id = 'u_' + rnd(6), salt = rnd()
  const data = await new Promise<string>((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.onerror = () => rej(new Error('leitura')); r.readAsDataURL(file) })
  try { docs.setState((s) => ({ d: { ...s.d, [id]: { type: file.type, data } } })) } catch { return 'Não foi possível guardar o documento (armazenamento cheio).' }
  put((s) => ({ users: [...s.users, { id, name: f.name.trim(), email, phone: dg(f.phone), cpf, birth: f.birth, role: f.role, perms: [], status: 'pending', docStatus: 'received', salt, hash: '', shop: f.shop, createdAt: now() }] }))
  patch(id, { hash: await hashPw(f.pw, salt) })
  return ''
}
const enter = (u: Account) => useStore.setState({ user: u.name, role: u.role, email: u.email })
export async function authLogin(emailIn: string, pw: string, as: 'buyer' | 'seller'): Promise<{ ok: boolean; err?: string; role?: Role }> {
  const u = st().users.find((x) => x.email === emailIn.trim().toLowerCase())
  const rm = useStore.getState().removed
  if (!u || !u.hash || (u.role !== 'admin' && u.role !== as) || rm.users.includes(u.email) || rm.sellers.includes(u.email) || (await hashPw(pw, u.salt)) !== u.hash) return { ok: false, err: 'E-mail ou senha inválidos.' }
  const wait = 'Seu cadastro foi recebido e está aguardando aprovação.'
  const msg: Record<Status, string> = { pending: wait, under_review: wait, rejected: 'Seu cadastro não foi aprovado.', suspended: 'Sua conta está temporariamente suspensa.', approved: '' }
  if (u.status !== 'approved') return { ok: false, err: msg[u.status] }
  enter(u)
  return { ok: true, role: u.role }
}

const target = (id: string) => st().users.find((u) => u.id === id && u.role !== 'admin')
export function review(id: string) {
  const t = target(id)
  if (!t || !canFor(t) || t.status !== 'pending') return
  patch(id, { status: 'under_review' }); log('iniciou análise do cadastro', t.role, id)
}
export function decide(id: string, ok: boolean, reason = ''): string {
  const t = target(id), u = me()
  if (!t || !u || !canFor(t)) return 'Sem permissão.'
  if (t.status !== 'pending' && t.status !== 'under_review') return 'Este cadastro já foi decidido.'
  if (!ok && !reason.trim()) return 'Informe o motivo da rejeição.'
  patch(id, { status: ok ? 'approved' : 'rejected', docStatus: ok ? 'approved' : 'rejected', decidedAt: now(), decidedBy: u.name, reason: ok ? undefined : reason.trim() })
  log(ok ? 'aprovou cadastro' : 'rejeitou cadastro', t.role, id, reason.trim() || undefined)
  return ''
}
export function readDoc(id: string) {
  const t = st().users.find((x) => x.id === id)
  if (!t || t.role === 'admin' || !canFor(t)) return null
  log('visualizou documento', t.role, id)
  return docs.getState().d[id] ?? null
}

export function requestAdmin(f: { name: string; email: string; phone: string; func: string; perms: string[]; reason: string }): string {
  const u = me(), email = f.email.trim().toLowerCase()
  if (!u || u.role !== 'admin') return 'Sem permissão.'
  if (!f.name.trim() || !validEmail(email) || !f.func.trim() || !f.reason.trim()) return 'Preencha nome, e-mail, função e motivo.'
  if (f.phone && !validPhone(f.phone)) return 'Telefone inválido.'
  if (st().users.some((x) => x.email === email) || st().reqs.some((r) => r.email === email && r.status === 'pending')) return 'Já existe conta ou solicitação com este e-mail.'
  put((s) => ({ reqs: [{ id: 'r_' + rnd(6), requesterId: u.id, name: f.name.trim(), email, phone: dg(f.phone), func: f.func.trim(), reason: f.reason.trim(), perms: f.perms.filter((p) => PERMS.some(([k]) => k === p)), status: 'pending', createdAt: now() }, ...s.reqs] }))
  log('solicitou novo administrador', 'admin_request', email, f.reason.trim())
  return ''
}
export async function decideReq(id: string, ok: boolean, reason = ''): Promise<{ err?: string; pw?: string }> {
  const u = me(), r = st().reqs.find((x) => x.id === id)
  if (!u || u.level !== 'primary') return { err: 'Somente o Admin 01 pode decidir.' }
  if (!r || r.status !== 'pending') return { err: 'A solicitação não está pendente.' }
  if (!ok && !reason.trim()) return { err: 'Informe o motivo da negativa.' }
  let pw: string | undefined
  if (ok) {
    if (st().users.some((x) => x.email === r.email)) return { err: 'Já existe conta com este e-mail.' }
    const salt = rnd(); pw = 'Tmp#' + rnd(5) + '1A'
    const a: Account = { id: 'u_' + rnd(6), name: r.name, email: r.email, phone: r.phone, cpf: '', birth: '', role: 'admin', level: 'secondary', func: r.func, perms: r.perms, status: 'approved', docStatus: 'approved', salt, hash: await hashPw(pw, salt), createdAt: now(), decidedAt: now(), decidedBy: u.name }
    put((s) => ({ users: [...s.users, a] }))
  }
  put((s) => ({ reqs: s.reqs.map((x) => (x.id === id ? { ...x, status: ok ? 'approved' : 'rejected', decidedAt: now(), decidedBy: u.name, decisionReason: reason.trim() || undefined } : x)) }))
  log(ok ? 'aprovou administrador' : 'rejeitou administrador', 'admin_request', r.email, reason.trim() || undefined)
  return { pw }
}
const adminTarget = (id: string) => { const u = me(), t = st().users.find((x) => x.id === id); return !u || u.level !== 'primary' ? 'Somente o Admin 01 pode fazer isso.' : !t || t.role !== 'admin' || t.level === 'primary' ? 'A conta do Admin 01 é protegida.' : '' }
export function adminAct(id: string, act: 'suspend' | 'reactivate' | 'remove'): string {
  const e = adminTarget(id)
  if (e) return e
  if (act === 'remove') put((s) => ({ users: s.users.filter((x) => x.id !== id) })); else patch(id, { status: act === 'suspend' ? 'suspended' : 'approved' })
  log({ suspend: 'suspendeu administrador', reactivate: 'reativou administrador', remove: 'removeu administrador' }[act], 'admin', id)
  return ''
}
export function setPerms(id: string, perms: string[]): string {
  const e = adminTarget(id)
  if (e) return e
  patch(id, { perms }); log('alterou permissões', 'admin', id, perms.join(', '))
  return ''
}

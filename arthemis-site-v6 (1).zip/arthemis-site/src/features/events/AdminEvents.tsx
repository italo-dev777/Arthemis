import { useState } from 'react'
import { Confirm } from '../../components/Confirm'
import { eventStatus, useStore, type EventItem } from '../../store'
import { toast } from '../../toast'
import { ST } from './Events'
import { ELIGIBLE, KIND_LABEL, METRICS, rankFor } from './logic'

const today = () => new Date().toISOString().slice(0, 10)
const plus = (n: number) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10)
const blank = (): EventItem => ({ id: 'EV-' + Math.random().toString(36).slice(2, 7).toUpperCase(), kind: 'sorteio', name: '', description: '', rules: '', prize: '', start: today(), end: plus(7), eligible: 'todos', metric: 'sales', participants: [], scores: {} })

export function AdminEvents() {
  const { events, orders, fees, removed, saveEvent, deleteEvent, drawWinner, finishEvent, setScore } = useStore()
  const [draft, setDraft] = useState<EventItem | null>(null)
  const [del, setDel] = useState<EventItem | null>(null)
  const set = <K extends keyof EventItem>(k: K, v: EventItem[K]) => setDraft((d) => (d ? { ...d, [k]: v } : d))
  const save = () => {
    if (!draft) return
    if (draft.name.trim().length < 3 || !draft.prize.trim()) return toast('Informe o nome do evento e o prêmio', 'err')
    if (draft.start > draft.end) return toast('A data de término deve ser igual ou posterior à de início', 'err')
    saveEvent({ ...draft, name: draft.name.trim(), prize: draft.prize.trim() }); setDraft(null)
  }
  return (
    <div className="space-y-4">
      <button className="btn btn-primary" onClick={() => setDraft(blank())}>+ Novo evento</button>
      {draft && (
        <section className="card space-y-3 p-5">
          <h2 className="text-lg">{events.some((e) => e.id === draft.id) ? 'Editar evento' : 'Novo evento'}</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="text-sm">Tipo<select className="input mt-1" value={draft.kind} onChange={(e) => set('kind', e.target.value as EventItem['kind'])}>{Object.entries(KIND_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
            <label className="text-sm">Nome<input className="input mt-1" value={draft.name} onChange={(e) => set('name', e.target.value)} /></label>
            <label className="text-sm">Início<input type="date" className="input mt-1" value={draft.start} onChange={(e) => set('start', e.target.value)} /></label>
            <label className="text-sm">Término<input type="date" className="input mt-1" value={draft.end} onChange={(e) => set('end', e.target.value)} /></label>
            <label className="text-sm">Prêmio<input className="input mt-1" value={draft.prize} onChange={(e) => set('prize', e.target.value)} /></label>
            <label className="text-sm">Participantes elegíveis<select className="input mt-1" value={draft.eligible} onChange={(e) => set('eligible', e.target.value as EventItem['eligible'])}>{Object.entries(ELIGIBLE).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
            {draft.kind === 'premio' && <label className="text-sm sm:col-span-2">Critério do ranking<select className="input mt-1" value={draft.metric ?? 'sales'} onChange={(e) => set('metric', e.target.value as EventItem['metric'])}>{Object.entries(METRICS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>}
          </div>
          <label className="block text-sm">Descrição<textarea className="input mt-1 h-20 py-2" value={draft.description} onChange={(e) => set('description', e.target.value)} /></label>
          <label className="block text-sm">Regras<textarea className="input mt-1 h-20 py-2" value={draft.rules} onChange={(e) => set('rules', e.target.value)} /></label>
          <div className="flex gap-2"><button className="btn btn-primary" onClick={save}>Salvar evento</button><button className="btn btn-ghost" onClick={() => setDraft(null)}>Cancelar</button></div>
        </section>
      )}
      {events.map((e) => {
        const st = eventStatus(e)
        return (
          <section key={e.id} className="card space-y-3 p-4">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div><p className="font-semibold">{e.name} <span className={`badge ${ST[st][1]}`}>{ST[st][0]}</span></p><p className="text-xs text-muted">{KIND_LABEL[e.kind]} · {e.start.split('-').reverse().join('/')} a {e.end.split('-').reverse().join('/')} · prêmio: {e.prize}{e.kind !== 'premio' ? ` · ${e.participants.length} participantes` : ''}{e.winner ? ` · vencedor: ${e.winner}` : ''}</p></div>
              <div className="flex flex-wrap gap-2">
                {!e.finished && e.kind === 'sorteio' && <button className="btn btn-primary btn-sm" onClick={() => drawWinner(e.id)}>Sortear vencedor</button>}
                {!e.finished && e.kind !== 'sorteio' && <button className="btn btn-primary btn-sm" onClick={() => finishEvent(e.id, e.kind === 'premio' ? rankFor(e, orders, fees, removed.sellers) : undefined)}>Finalizar e definir vencedor</button>}
                <button className="btn btn-ghost btn-sm" onClick={() => setDraft(e)}>Editar</button>
                <button className="btn btn-ghost btn-sm" onClick={() => setDel(e)}>Excluir</button>
              </div>
            </div>
            {e.kind === 'disputa' && (e.participants.length ? (
              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">{e.participants.map((p) => (
                <label key={p} className="flex items-center justify-between gap-2 text-sm">{p}<input type="number" min={0} className="input h-9 w-24 px-2" disabled={!!e.finished} value={e.scores[p] ?? 0} onChange={(ev) => setScore(e.id, p, Math.max(0, Number(ev.target.value) || 0))} /></label>
              ))}</div>
            ) : <p className="text-sm text-muted">Sem participantes inscritos ainda.</p>)}
          </section>
        )
      })}
      {del && <Confirm title="Excluir evento?" confirmLabel="Excluir" onCancel={() => setDel(null)} onConfirm={() => { deleteEvent(del.id); setDel(null) }}><p><b>{del.name}</b> ({KIND_LABEL[del.kind]})</p><p className="text-muted">As inscrições e a pontuação deste evento serão apagadas.</p></Confirm>}
    </div>
  )
}

import { useState } from 'react'
import { brl } from '../../data'
import { eventStatus, useStore, type EventItem, type EventStatus } from '../../store'
import { ELIGIBLE, METRICS, rankFor } from './logic'

const KINDS = [['premio', '🏆 Premiações'], ['sorteio', '🎁 Sorteios'], ['disputa', '🎮 Disputas e jogos']] as const
export const ST: Record<EventStatus, [string, string]> = { proximo: ['Próximo', 'badge-warning'], ativo: ['Ativo', 'badge-success'], encerrado: ['Encerrado', 'badge-danger'], finalizado: ['Finalizado', 'bg-card-hover text-muted'] }
const ORDER: Record<EventStatus, number> = { ativo: 0, proximo: 1, encerrado: 2, finalizado: 3 }
const day = (d: string) => d.split('-').reverse().join('/')

function EventCard({ e }: { e: EventItem }) {
  const { orders, fees, removed, user, joinEvent } = useStore()
  const [rules, setRules] = useState(false)
  const st = eventStatus(e)
  const rank = e.finished && e.ranking ? e.ranking : e.kind === 'premio' ? rankFor(e, orders, fees, removed.sellers) : e.kind === 'disputa' ? Object.entries(e.scores).sort((a, b) => b[1] - a[1]) : []
  const joined = !!user && e.participants.includes(user)
  const open = st === 'proximo' || st === 'ativo'
  return (
    <section className="card space-y-3 p-5">
      <div className="flex items-start justify-between gap-2"><h2 className="text-lg">{e.name}</h2><span className={`badge ${ST[st][1]}`}>{ST[st][0]}</span></div>
      <p className="text-sm text-muted">{e.description}</p>
      <div className="space-y-0.5 text-sm"><p>📅 {day(e.start)} a {day(e.end)}</p><p>🎁 Prêmio: <b>{e.prize}</b></p><p>👥 Elegíveis: {ELIGIBLE[e.eligible]}</p>{e.kind === 'premio' && e.metric && <p>📊 Critério: {METRICS[e.metric]}</p>}{e.kind !== 'premio' && <p>🙋 {e.participants.length} participantes</p>}</div>
      {e.winner && <p className="alert alert-success">🏆 {e.kind === 'sorteio' ? 'Vencedor' : 'Campeão'}: <b>{e.winner}</b></p>}
      {rank.length > 0 && <ol className="space-y-1 text-sm">{rank.slice(0, 5).map(([n, v], i) => <li key={n} className="flex justify-between"><span>{i + 1}º {n}</span><b>{e.kind === 'premio' ? brl(v) : `${v} pts`}</b></li>)}</ol>}
      {e.kind === 'premio' && !rank.length && <p className="text-sm text-muted">Ainda não há vendas no período.</p>}
      <button className="text-sm text-primary" onClick={() => setRules(!rules)}>{rules ? 'Ocultar regras' : 'Ver regras'}</button>
      {rules && <p className="rounded-md bg-card-hover p-3 text-sm">{e.rules}</p>}
      {e.kind !== 'premio' && open && <button className={`btn w-full ${joined ? 'btn-ghost' : 'btn-primary'}`} onClick={() => joinEvent(e.id)}>{joined ? 'Participando ✓ (cancelar)' : e.kind === 'sorteio' ? 'Participar do sorteio' : 'Inscrever-se'}</button>}
    </section>
  )
}

export function Events() {
  const events = useStore((s) => s.events)
  const [tab, setTab] = useState<(typeof KINDS)[number][0]>('premio')
  const [st, setSt] = useState('')
  const list = events.filter((e) => e.kind === tab && (!st || eventStatus(e) === st)).sort((a, b) => ORDER[eventStatus(a)] - ORDER[eventStatus(b)])
  return (
    <div className="space-y-5">
      <div><p className="eyebrow">Eventos</p><h1 className="text-3xl">Premiações, sorteios e disputas</h1></div>
      <div className="flex flex-wrap items-center gap-2">
        <nav className="flex flex-wrap gap-2" aria-label="Tipo de evento">{KINDS.map(([id, t]) => <button key={id} onClick={() => setTab(id)} className={`chip ${tab === id ? 'chip-active' : ''}`}>{t}</button>)}</nav>
        <select className="input ml-auto h-9 w-auto" aria-label="Filtrar por status" value={st} onChange={(e) => setSt(e.target.value)}><option value="">Todos os status</option>{Object.entries(ST).map(([k, v]) => <option key={k} value={k}>{v[0]}</option>)}</select>
      </div>
      {list.length ? <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">{list.map((e) => <EventCard key={e.id} e={e} />)}</div> : <p className="py-16 text-center text-muted">Nenhum evento nesta categoria.</p>}
    </div>
  )
}

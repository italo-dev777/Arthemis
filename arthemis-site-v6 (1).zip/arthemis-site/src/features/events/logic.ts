import { DEFAULT_FEE, sales } from '../../finance'
import type { EventItem, Order } from '../../store'

export const METRICS: Record<NonNullable<EventItem['metric']>, string> = { sales: 'Maior valor vendido', revenue: 'Maior faturamento (líquido)', purchases: 'Maior valor em compras', affiliate: 'Comissão de afiliado' }
export const KIND_LABEL = { premio: 'Premiação', sorteio: 'Sorteio', disputa: 'Disputa / jogo' } as const
export const ELIGIBLE = { todos: 'Todos os usuários', compradores: 'Compradores', vendedores: 'Vendedores' } as const

// Ranking de uma premiação: considera só as vendas feitas entre a data de início e a de término do evento
export function rankFor(e: EventItem, orders: Order[], fees: { platform: Record<string, number>; aff: number }, gone: string[]): [string, number][] {
  const m = new Map<string, number>()
  const add = (k: string, v: number) => m.set(k, (m.get(k) ?? 0) + v)
  for (const s of sales(orders)) {
    const d = s.date.slice(0, 10)
    if (d < e.start || d > e.end || gone.includes(s.seller)) continue
    const pct = fees.platform[s.seller] ?? DEFAULT_FEE
    const metric = e.metric ?? 'sales'
    if (metric === 'sales') add('@' + s.seller, s.value)
    else if (metric === 'revenue') add('@' + s.seller, s.value - (s.value * pct) / 100)
    else if (metric === 'purchases') add(s.buyer, s.value)
    else if (s.ref) add(s.ref, (s.value * fees.aff) / 100)
  }
  return [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5)
}

import { Navigate } from 'react-router-dom'
import { ArthemisScore } from '../../components/Score'
import { brl } from '../../data'
import { useStore } from '../../store'
import { Withdraw } from '../wallet/Withdraw'
const STATS: [string, string][] = [['Vendas hoje', 'R$ 1.284'], ['Vendas mês', 'R$ 28.492'], ['Pedidos', '382'], ['Avaliação', '4.9']]
export function SellerPanel() {
  const sellerBalance = useStore((s) => s.sellerBalance)
  const user = useStore((s) => s.user)
  const role = useStore((s) => s.role)
  if (!user) return <Navigate to="/login" replace />
  if (role === 'buyer') return <Navigate to="/" replace />
  return (
    <div className="space-y-5">
      <p className="eyebrow">Painel do vendedor</p>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {[...STATS, ['Saldo disponível', brl(sellerBalance)] as [string, string]].map(([k, v]) => <div key={k} className="card p-4"><p className="text-xs text-muted">{k}</p><p className="font-display text-2xl">{v}</p></div>)}
      </div>
      <div className="max-w-sm"><ArthemisScore /></div>
      <Withdraw source="seller" />
    </div>
  )
}

import { useState } from 'react'
import { Link } from 'react-router-dom'
import { LifeBuoy, X } from 'lucide-react'
import { products } from '../../data'
import { CLOSED, D_STATUS, T_STATUS, statusLabel, useStore, type Status, type Ticket } from '../../store'
import { toast } from '../../toast'

const CATS = ['Dúvida', 'Problema', 'Erro no site', 'Suporte', 'Sugestão', 'Denúncia']
const REASONS = ['Fraude ou golpe', 'Produto diferente do anunciado', 'Conteúdo ofensivo', 'Spam ou propaganda', 'Outro']
const BADGE: Record<string, string> = { aberto: 'badge-warning', nova: 'badge-warning', aguardando: 'badge-warning', atendimento: 'badge-success', analise: 'badge-success', respondida: 'badge-success', resolvido: 'badge-success', resolvida: 'badge-success', fechado: 'badge-danger', encerrada: 'badge-danger' }
const when = (d: string) => new Date(d).toLocaleString('pt-BR')
const Badge = ({ s }: { s: string }) => <span className={`badge ${BADGE[s] ?? ''}`}>{statusLabel(s)}</span>

function Thread({ t }: { t: Ticket }) {
  return (
    <div className="space-y-2">
      {t.msgs.map((m, i) => (
        <div key={i} className={`max-w-[90%] rounded-md px-3 py-2 text-sm ${m.from === 'admin' ? 'bg-card-hover' : 'ml-auto bg-primary/20'}`}>
          <p className="text-xs text-muted">{m.from === 'admin' ? 'Suporte Arthemis' : t.user} · {when(m.date)}</p>{m.text}
        </div>
      ))}
    </div>
  )
}
function Reply({ label, button, onSend }: { label: string; button: string; onSend: (text: string) => void }) {
  const [v, setV] = useState('')
  return (
    <div className="space-y-2">
      <textarea className="input h-20 py-2" aria-label={label} placeholder={label} value={v} onChange={(e) => setV(e.target.value)} />
      <button className="btn btn-primary btn-sm" disabled={!v.trim()} onClick={() => { onSend(v.trim()); setV('') }}>{button}</button>
    </div>
  )
}

export function TicketFab() {
  const { user, tickets, openTicket, replyTicket, setTicketStatus } = useStore()
  const [open, setOpen] = useState(false)
  const [tab, setTab] = useState<'new' | 'mine'>('new')
  const [sel, setSel] = useState('')
  const [cat, setCat] = useState(CATS[0])
  const [subject, setSubject] = useState('')
  const [target, setTarget] = useState('')
  const [reason, setReason] = useState(REASONS[0])
  const [related, setRelated] = useState('')
  const [text, setText] = useState('')
  const mine = tickets.filter((t) => t.user === user).sort((a, b) => b.updated.localeCompare(a.updated))
  const waiting = mine.filter((t) => t.status === 'aguardando' || t.status === 'respondida').length
  const report = cat === 'Denúncia'
  const submit = () => {
    if (subject.trim().length < 3 || text.trim().length < 10 || (report && !target.trim())) return toast(report ? 'Informe quem está denunciando, o assunto e uma descrição (mín. 10 letras)' : 'Informe o assunto e uma descrição (mín. 10 letras)', 'err')
    if (openTicket({ kind: report ? 'denuncia' : 'ticket', topic: cat, subject: subject.trim(), target: report ? target.trim() : undefined, reason: report ? reason : undefined, related: report && related.trim() ? related.trim() : undefined, text: text.trim() })) { setSubject(''); setTarget(''); setRelated(''); setText(''); setTab('mine') }
  }
  return (
    <>
      {open && (
        <div className="card fixed right-4 bottom-36 z-40 max-h-[70vh] w-[min(24rem,calc(100vw-2rem))] space-y-3 overflow-y-auto p-4 shadow-e3 md:bottom-24" role="dialog" aria-label="Tickets de suporte">
          <div className="flex items-center justify-between"><h2 className="text-lg">Suporte</h2><button aria-label="Fechar" onClick={() => setOpen(false)}><X className="h-4 w-4" /></button></div>
          {!user ? <p className="text-sm text-muted">Para abrir ou acompanhar tickets, <Link to="/login" onClick={() => setOpen(false)} className="text-primary">entre na sua conta</Link>.</p> : (
            <>
              <div className="flex gap-2"><button onClick={() => setTab('new')} className={`chip ${tab === 'new' ? 'chip-active' : ''}`}>Novo ticket</button><button onClick={() => setTab('mine')} className={`chip ${tab === 'mine' ? 'chip-active' : ''}`}>Meus tickets ({mine.length})</button></div>
              {tab === 'new' ? (
                <div className="space-y-2">
                  <select className="input" aria-label="Categoria" value={cat} onChange={(e) => setCat(e.target.value)}>{CATS.map((c) => <option key={c}>{c}</option>)}</select>
                  {report && <>
                    <input className="input" placeholder="Quem ou o que você está denunciando?" value={target} onChange={(e) => setTarget(e.target.value)} />
                    <select className="input" aria-label="Motivo" value={reason} onChange={(e) => setReason(e.target.value)}>{REASONS.map((c) => <option key={c}>{c}</option>)}</select>
                    <input className="input" placeholder="Pedido, produto ou link relacionado (opcional)" value={related} onChange={(e) => setRelated(e.target.value)} />
                  </>}
                  <input className="input" placeholder="Assunto" value={subject} onChange={(e) => setSubject(e.target.value)} />
                  <textarea className="input h-24 py-2" placeholder="Descreva sua dúvida, problema ou denúncia" value={text} onChange={(e) => setText(e.target.value)} />
                  <button className="btn btn-primary w-full" onClick={submit}>{report ? 'Enviar denúncia' : 'Abrir ticket'}</button>
                </div>
              ) : !mine.length ? <p className="py-6 text-center text-sm text-muted">Você ainda não abriu nenhum ticket.</p> : mine.map((t) => (
                <div key={t.id} className="rounded-md border border-border p-3">
                  <button className="w-full space-y-1 text-left text-sm" onClick={() => setSel(sel === t.id ? '' : t.id)}>
                    <span className="flex items-center justify-between gap-2"><span className="font-medium">{t.subject}</span><Badge s={t.status} /></span>
                    <span className="block text-xs text-muted">{t.id} · {t.topic} · atualizado em {when(t.updated)}</span>
                  </button>
                  {sel === t.id && <div className="mt-3 space-y-3"><Thread t={t} />
                    {CLOSED.includes(t.status) ? <p className="text-xs text-muted">Este ticket está encerrado.</p> : <>
                      <Reply label="Escreva uma resposta" button="Enviar" onSend={(v) => replyTicket(t.id, 'user', v)} />
                      {t.kind === 'ticket' && t.status !== 'resolvido' && <button className="btn btn-ghost btn-sm" onClick={() => setTicketStatus(t.id, 'resolvido')}>Marcar como resolvido</button>}
                    </>}
                  </div>}
                </div>
              ))}
            </>
          )}
        </div>
      )}
      <button onClick={() => setOpen(!open)} aria-label="Abrir tickets de suporte" className="btn btn-primary fixed right-3 bottom-20 z-40 h-11 w-11 gap-0 rounded-full p-0 shadow-e3 md:right-4 md:bottom-6 md:h-12 md:w-auto md:gap-2 md:px-4"><LifeBuoy className="h-5 w-5" /><span className="hidden md:inline">Tickets</span>{waiting > 0 && <span className="badge bg-background text-primary">{waiting}</span>}</button>
    </>
  )
}

export function AdminTickets({ kind }: { kind: Ticket['kind'] }) {
  const { tickets, replyTicket, setTicketStatus } = useStore()
  const rep = kind === 'denuncia'
  const [q, setQ] = useState(''), [st, setSt] = useState(''), [cat, setCat] = useState(''), [sel, setSel] = useState('')
  const needle = q.trim().toLowerCase()
  const list = tickets.filter((t) => t.kind === kind && (!st || t.status === st) && (!cat || (t.reason ?? t.topic) === cat)
    && (!needle || [t.id, t.subject, t.user, t.target ?? '', ...t.msgs.map((m) => m.text)].join(' ').toLowerCase().includes(needle))).sort((a, b) => b.updated.localeCompare(a.updated))
  const statuses = Object.entries(rep ? D_STATUS : T_STATUS) as [Status, string][]
  const cats = rep ? REASONS : CATS.filter((c) => c !== 'Denúncia')
  const Info = ({ k, v }: { k: string; v?: string }) => v ? <p><span className="text-muted">{k}: </span>{v}</p> : null
  return (
    <div className="space-y-3">
      <div className="grid gap-2 sm:grid-cols-3">
        <input className="input" aria-label="Pesquisar" placeholder="Pesquisar (ID, usuário, assunto, texto)" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="input" aria-label="Filtrar por status" value={st} onChange={(e) => setSt(e.target.value)}><option value="">Todos os status</option>{statuses.map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
        <select className="input" aria-label={rep ? 'Filtrar por motivo' : 'Filtrar por categoria'} value={cat} onChange={(e) => setCat(e.target.value)}><option value="">{rep ? 'Todos os motivos' : 'Todas as categorias'}</option>{cats.map((c) => <option key={c}>{c}</option>)}</select>
      </div>
      {!list.length && <p className="card p-8 text-center text-muted">{tickets.some((t) => t.kind === kind) ? 'Nada encontrado com esses filtros.' : rep ? 'Nenhuma denúncia recebida.' : 'Nenhum ticket recebido.'}</p>}
      {list.map((t) => {
        const seller = (t.target ?? '').startsWith('@') ? (t.target ?? '').slice(1) : ''
        const sp = products.filter((p) => p.seller === seller)
        const others = tickets.filter((x) => x.kind === 'denuncia' && x.id !== t.id && x.target === t.target).length
        return (
          <div key={t.id} className="card p-4">
            <button className="flex w-full flex-wrap items-center justify-between gap-2 text-left" onClick={() => setSel(sel === t.id ? '' : t.id)}>
              <span><b>{t.subject}</b><span className="block text-xs text-muted">{t.id.startsWith('EX-') && <span className="badge badge-warning mr-1">exemplo</span>}{t.id} · {t.user} · {t.reason ?? t.topic} · atualizado em {when(t.updated)}</span></span>
              <Badge s={t.status} />
            </button>
            {sel === t.id && (
              <div className="mt-4 space-y-4">
                <div className="grid gap-1 rounded-md bg-card-hover p-3 text-sm sm:grid-cols-2">
                  <Info k="ID" v={t.id} /><Info k={rep ? 'Denunciante' : 'Usuário'} v={t.user} />
                  {rep ? <><Info k="Denunciado" v={t.target} /><Info k="Motivo" v={t.reason} /><Info k="Informações relacionadas" v={t.related} /></> : <Info k="Categoria" v={t.topic} />}
                  <Info k="Aberto em" v={when(t.date)} /><Info k="Última atualização" v={when(t.updated)} />
                  {rep && seller && sp.length > 0 && <Info k={`Vendedor @${seller}`} v={`${sp.length} produtos, ${sp.reduce((a, p) => a + p.sales, 0)} vendas`} />}
                  {rep && <Info k="Outras denúncias contra o mesmo alvo" v={String(others)} />}
                </div>
                <Thread t={t} />
                {!CLOSED.includes(t.status) && <Reply label={rep ? 'Registrar resposta ou decisão' : 'Responder ao ticket'} button={rep ? 'Registrar resposta' : 'Enviar resposta'} onSend={(v) => replyTicket(t.id, 'admin', v)} />}
                <div className="flex flex-wrap items-center gap-2">
                  <label className="text-sm text-muted">Status
                    <select className="input ml-2 h-9 w-auto" value={t.status} onChange={(e) => setTicketStatus(t.id, e.target.value as Status)}>{statuses.map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
                  {CLOSED.includes(t.status)
                    ? <button className="btn btn-ghost btn-sm" onClick={() => setTicketStatus(t.id, rep ? 'nova' : 'aberto')}>Reabrir</button>
                    : <button className="btn btn-ghost btn-sm" onClick={() => setTicketStatus(t.id, rep ? 'encerrada' : 'fechado')}>{rep ? 'Encerrar denúncia' : 'Encerrar ticket'}</button>}
                </div>
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}

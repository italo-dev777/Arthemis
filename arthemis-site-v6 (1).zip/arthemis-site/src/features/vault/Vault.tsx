import { Link } from 'react-router-dom'
import { Copy, Download } from 'lucide-react'
import { products } from '../../data'
import { useStore } from '../../store'
import { toast } from '../../toast'

const save = (name: string, key: string, order: string) => {
  const url = URL.createObjectURL(new Blob([`Arthemis (demonstração)\nPedido: ${order}\nProduto: ${name}\nChave de acesso: ${key}\n`], { type: 'text/plain' }))
  Object.assign(document.createElement('a'), { href: url, download: `${name}.txt` }).click()
  URL.revokeObjectURL(url)
}

export function Vault() {
  const orders = useStore((s) => s.orders)
  const items = orders.flatMap((o) => o.items.map((it) => ({ ...it, order: o.id, date: o.date, p: products.find((x) => x.slug === it.slug) }))).filter((i) => i.p)
  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <p className="eyebrow">Meu cofre digital</p>
      <h1 className="text-3xl">Seus produtos</h1>
      {!items.length && <div className="card space-y-2 p-8 text-center"><p>Você ainda não comprou nenhum produto.</p><Link to="/marketplace" className="btn btn-primary">Explorar marketplace</Link></div>}
      {items.map((i) => (
        <div key={i.order + i.slug} className="card space-y-3 p-4">
          <div className="flex items-center justify-between gap-3">
            <p className="font-semibold">{i.p!.emoji} {i.p!.name}</p>
            <span className="text-xs text-muted">{i.order} · {new Date(i.date).toLocaleDateString('pt-BR')}</span>
          </div>
          <code className="block rounded-md bg-card-hover p-2 text-sm">{i.key}</code>
          <div className="flex flex-wrap gap-2">
            <button className="btn btn-ghost btn-sm" onClick={() => { navigator.clipboard?.writeText(i.key); toast('Chave copiada') }}><Copy className="h-4 w-4" />Copiar chave</button>
            <button className="btn btn-primary btn-sm" onClick={() => save(i.p!.name, i.key, i.order)}><Download className="h-4 w-4" />Baixar</button>
            <Link to={`/produto/${i.slug}`} className="btn btn-ghost btn-sm">Avaliar</Link>
          </div>
        </div>
      ))}
    </div>
  )
}

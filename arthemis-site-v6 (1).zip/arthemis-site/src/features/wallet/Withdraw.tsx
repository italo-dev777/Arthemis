import { useState } from 'react'
import { brl } from '../../data'
import { useStore } from '../../store'

export function Withdraw({ source }: { source: 'buyer' | 'seller' }) {
  const { balance, sellerBalance, withdraw } = useStore()
  const avail = source === 'buyer' ? balance : sellerBalance
  const [amount, setAmount] = useState('')
  const [type, setType] = useState('cpf')
  const [key, setKey] = useState('')
  const hint: Record<string, string> = { cpf: '000.000.000-00', email: 'voce@email.com', tel: '(11) 99999-9999', rand: 'Chave aleatória (32 caracteres)' }
  const n = Number(amount.replace(',', '.'))
  return (
    <section className="card max-w-xl space-y-3 p-5">
      <h2 className="text-lg">Transferir saldo para o meu PIX</h2>
      <p className="text-sm text-muted">Saldo disponível: <b className="text-foreground">{brl(avail)}</b> · mínimo R$ 10,00</p>
      <div className="flex flex-wrap gap-2">{[10, 50, 100].map((v) => <button key={v} type="button" disabled={v > avail} onClick={() => setAmount(String(v))} className="chip">{brl(v)}</button>)}<button type="button" disabled={avail < 10} onClick={() => setAmount(String(avail))} className="chip">Tudo</button></div>
      <label className="block text-sm">Valor (R$)<input className="input mt-1" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0,00" /></label>
      <div className="grid gap-3 sm:grid-cols-[150px_1fr]">
        <label className="block text-sm">Tipo da chave<select className="input mt-1" value={type} onChange={(e) => setType(e.target.value)}><option value="cpf">CPF</option><option value="email">E-mail</option><option value="tel">Telefone</option><option value="rand">Aleatória</option></select></label>
        <label className="block text-sm">Chave PIX<input className="input mt-1" value={key} onChange={(e) => setKey(e.target.value)} placeholder={hint[type]} /></label>
      </div>
      <button className="btn btn-primary w-full" onClick={() => { if (withdraw(source, n, type, key)) { setAmount(''); setKey('') } }}>Transferir para o PIX</button>
      <p className="text-xs text-muted">Demonstração: nenhum PIX real é enviado e a chave não fica salva.</p>
    </section>
  )
}

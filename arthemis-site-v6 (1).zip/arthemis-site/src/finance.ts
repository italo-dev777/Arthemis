import { products } from './data'
import type { Order } from './store'
export const DEFAULT_FEE = 10 // % da plataforma por venda (valor inicial, editável no Admin)
export type Sale = { id: string; date: string; slug: string; name: string; seller: string; buyer: string; ref: string; value: number; demo?: boolean }
// Vendas de exemplo para Admin e Eventos não ficarem vazios (marcadas como "exemplo")
const SEED: [string, number, string, number, string][] = [
  ['minecraft-premium', 1, 'DEMO', 1, 'Maria S.'], ['gift-card-steam-50', 2, '', 2, 'João P.'], ['conta-valorant', 1, 'MARIA', 3, 'Ana L.'], ['netflix-1-mes', 3, '', 4, 'Maria S.'],
  ['spotify-premium-3-meses', 1, 'DEMO', 5, 'Lucas M.'], ['gta-v-premium', 1, '', 6, 'Beatriz R.'], ['conta-fortnite', 1, 'JOAO', 7, 'João P.'],
]
export function sales(orders: Order[]): Sale[] {
  const real = orders.flatMap((o) => o.items.flatMap((it) => {
    const p = products.find((x) => x.slug === it.slug)
    return p ? [{ id: `${o.id}-${p.slug}`, date: o.date, slug: p.slug, name: p.name, seller: p.seller, buyer: 'Demo', ref: o.ref ?? '', value: p.price * it.qty }] : []
  }))
  const demo = SEED.flatMap(([slug, qty, ref, ago, buyer], i) => {
    const p = products.find((x) => x.slug === slug)
    return p ? [{ id: `EX-${i + 1}`, date: new Date(Date.now() - ago * 864e5).toISOString(), slug, name: p.name, seller: p.seller, buyer, ref, value: p.price * qty, demo: true }] : []
  })
  return [...real, ...demo]
}

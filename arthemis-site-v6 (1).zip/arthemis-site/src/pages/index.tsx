import { useMemo, useState } from 'react'
import { Link, Navigate, useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { Check, ChevronLeft, ChevronRight, Heart, ShoppingBag, Star, Store } from 'lucide-react'
import { brl, categories, info, type Product } from '../data'
import { useStore } from '../store'
import { ArthemisScore } from '../components/Score'
import { Price, SkeletonCard, Stars, rate, useCatalog, useLoading } from '../components/ui'
import { toast } from '../toast'
import { authLogin } from '../features/auth/auth'

function ProductCard({ p }: { p: Product }) {
  const { favs, toggleFav, add, reviews } = useStore()
  const r = rate(p, reviews)
  const fav = favs.includes(p.slug)
  return (
    <article className="card card-interactive group overflow-hidden">
      <Link to={`/produto/${p.slug}`} className="thumb group-hover:scale-105" aria-label={p.name}>{p.emoji}</Link>
      <div className="space-y-1 p-4">
        <p className="text-xs text-muted">{categories.find((c) => c.id === p.cat)?.name}</p>
        <h3 className="font-semibold">{p.name}</h3>
        <p className="flex items-center gap-1 text-sm"><Star className="h-4 w-4 fill-warning text-warning" />{r.avg.toFixed(1)} <span className="text-muted">· por @{p.seller}</span></p>
        <Price p={p} />
        <div className="flex gap-2 pt-2">
          <button onClick={() => add(p.slug)} className="btn btn-primary btn-sm flex-1">Adicionar</button>
          <button aria-label="Favoritar" onClick={() => toggleFav(p.slug)} className="btn btn-ghost btn-sm"><Heart className={`h-4 w-4 ${fav ? 'fill-danger text-danger' : ''}`} /></button>
        </div>
      </div>
    </article>
  )
}
function Grid({ items }: { items: Product[] }) {
  const loading = useLoading(450)
  return <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">{loading ? items.map((p) => <SkeletonCard key={p.slug} />) : items.map((p) => <ProductCard key={p.slug} p={p} />)}</div>
}

export function Home() {
  const products = useCatalog()
  const best = [...products].sort((a, b) => b.sales - a.sales).slice(0, 4)
  return (
    <div className="space-y-14">
      <section className="hero fade-up p-8 md:p-16">
        <p className="eyebrow mb-3">Marketplace digital</p>
        <h1 className="max-w-2xl text-4xl md:text-6xl">Seu próximo item digital está aqui.</h1>
        <p className="mt-4 max-w-xl text-muted">Descubra, compre e venda produtos digitais em um marketplace criado para a nova economia.</p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link to="/marketplace" className="btn btn-primary">Explorar marketplace</Link>
          <Link to="/dashboard" className="btn btn-ghost">Começar a vender</Link>
        </div>
      </section>
      <section><h2 className="section-title mb-4">Explore por categoria</h2>
        <div className="flex snap-x gap-3 overflow-x-auto pb-2 md:grid md:grid-cols-5 md:overflow-visible">{categories.map((c) => (
          <Link key={c.id} to={`/marketplace?cat=${c.id}`} className="card card-interactive min-w-36 shrink-0 snap-start p-4 md:min-w-0">
            <span className="text-3xl">{c.emoji}</span><p className="mt-2 font-medium">{c.name}</p><p className="text-xs text-muted">{products.filter((p) => p.cat === c.id).length} produtos</p>
          </Link>))}</div></section>
      <section><h2 className="section-title mb-4">🔥 Ofertas</h2><Grid items={products.filter((p) => p.old).slice(0, 4)} /></section>
      <section><h2 className="section-title mb-4">Mais vendidos</h2><Grid items={best} /></section>
      <section className="grid gap-3 md:grid-cols-3">{['🛡️ Compra protegida', '⚡ Entrega digital', '⭐ Vendedores avaliados'].map((t) => <div key={t} className="card p-5 font-medium">{t}</div>)}</section>
    </div>
  )
}

export function Marketplace() {
  const products = useCatalog()
  const [sp] = useSearchParams()
  const [cat, setCat] = useState(sp.get('cat') ?? '')
  const [max, setMax] = useState(300)
  const [minRating, setMinRating] = useState(0)
  const [sort, setSort] = useState('sales')
  const q = (sp.get('q') ?? '').toLowerCase()
  const list = useMemo(() => products
    .filter((p) => (!cat || p.cat === cat) && p.price <= max && p.rating >= minRating && (p.name + p.seller).toLowerCase().includes(q))
    .sort((a, b) => sort === 'low' ? a.price - b.price : sort === 'high' ? b.price - a.price : sort === 'rating' ? b.rating - a.rating : b.sales - a.sales), [cat, max, minRating, sort, q, products])
  const sel = 'input w-auto'
  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-bold">Marketplace {q && <span className="text-muted">· "{q}"</span>}</h1>
      <div className="flex flex-wrap items-center gap-3">
        <select aria-label="Categoria" className={sel} value={cat} onChange={(e) => setCat(e.target.value)}><option value="">Todas as categorias</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
        <select aria-label="Avaliação mínima" className={sel} value={minRating} onChange={(e) => setMinRating(+e.target.value)}><option value={0}>Qualquer avaliação</option><option value={4.5}>4.5+</option><option value={4.8}>4.8+</option></select>
        <select aria-label="Ordenar" className={sel} value={sort} onChange={(e) => setSort(e.target.value)}><option value="sales">Mais vendidos</option><option value="low">Menor preço</option><option value="high">Maior preço</option><option value="rating">Melhor avaliação</option></select>
        <label className="flex items-center gap-2 text-sm">Até {brl(max)}<input type="range" min={20} max={300} value={max} onChange={(e) => setMax(+e.target.value)} /></label>
      </div>
      {list.length ? <Grid items={list} /> : <p className="py-16 text-center text-muted">Nenhum produto encontrado com esses filtros.</p>}
    </div>
  )
}

export function ProductPage() {
  const products = useCatalog()
  const { slug } = useParams()
  const nav = useNavigate()
  const { add, toggleFav, favs, reviews, orders, user, addReview } = useStore()
  const loading = useLoading(400)
  const [i, setI] = useState(0)
  const [stars, setStars] = useState(5)
  const [text, setText] = useState('')
  const p = products.find((x) => x.slug === slug)
  if (!p) return <p className="py-20 text-center text-muted">Produto inexistente.</p>
  if (loading) return <div className="grid gap-8 md:grid-cols-2" aria-hidden="true"><div className="skeleton h-72" /><div className="space-y-3"><div className="skeleton h-4 w-1/2" /><div className="skeleton h-8 w-3/4" /><div className="skeleton h-4 w-1/3" /><div className="skeleton h-10 w-1/3" /><div className="skeleton h-24" /></div></div>
  const r = rate(p, reviews)
  const mine = reviews.filter((x) => x.slug === p.slug)
  const bought = !!user && orders.some((o) => o.items.some((it) => it.slug === p.slug))
  const reviewed = mine.some((x) => x.user === user)
  const slides = ['Visão geral', 'No celular', 'Entrega imediata']
  const { includes, requires } = info[p.cat]
  const list = (t: string, items: string[]) => <section className="card p-5"><h2 className="mb-3 text-lg">{t}</h2><ul className="space-y-2 text-sm">{items.map((x) => <li key={x} className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-success" />{x}</li>)}</ul></section>
  return (
    <div className="space-y-10">
      <div className="grid gap-8 md:grid-cols-2">
        <div className="thumb relative h-72 rounded-xl text-8xl">
          {i === 0 && p.emoji}
          {i === 1 && <div className="w-28 rounded-2xl border-4 border-border bg-card py-6 text-center text-5xl">{p.emoji}</div>}
          {i === 2 && <p className="px-6 text-center text-xl font-display">⚡ Chave liberada logo após o PIX</p>}
          <span className="absolute bottom-3 left-3 text-sm text-muted">{slides[i]}</span>
          <button className="btn btn-ghost btn-sm absolute left-2 top-1/2 px-2" aria-label="Imagem anterior" onClick={() => setI((i + 2) % 3)}><ChevronLeft className="h-4 w-4" /></button>
          <button className="btn btn-ghost btn-sm absolute right-2 top-1/2 px-2" aria-label="Próxima imagem" onClick={() => setI((i + 1) % 3)}><ChevronRight className="h-4 w-4" /></button>
        </div>
        <div className="space-y-3">
          <p className="text-sm text-muted"><Link to="/marketplace">Marketplace</Link> / {p.name}</p>
          <h1 className="text-3xl font-bold">{p.name}</h1>
          <p className="flex items-center gap-2 text-sm"><Stars value={r.avg} />{r.avg.toFixed(1)} · {p.sales} vendas · por @{p.seller} ✓</p>
          <Price p={p} big />
          <div className="flex flex-wrap gap-2">
            <button onClick={() => { add(p.slug); nav('/carrinho') }} className="btn btn-primary">Comprar agora</button>
            <button onClick={() => add(p.slug)} className="btn btn-ghost">Adicionar ao carrinho</button>
            <button onClick={() => toggleFav(p.slug)} className="btn btn-ghost">{favs.includes(p.slug) ? '♥ Favorito' : '♡ Favoritar'}</button>
          </div>
          <ul className="pt-2 text-sm text-muted"><li>🛡️ Compra protegida</li><li>⚡ Entrega digital</li><li>💬 Suporte ao comprador</li></ul>
          <ArthemisScore />
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-2">{list('O que está incluso', includes)}{list('Requisitos', requires)}</div>
      <section className="space-y-4">
        <h2 className="section-title">Avaliações de compradores</h2>
        {bought && !reviewed ? (
          <div className="card space-y-3 p-4">
            <Stars value={stars} onChange={setStars} />
            <textarea className="input h-24 py-2" placeholder="Conte como foi a sua experiência" value={text} onChange={(e) => setText(e.target.value)} />
            <button className="btn btn-primary" disabled={!text.trim()} onClick={() => { addReview({ slug: p.slug, user: user!, rating: stars, text: text.trim(), date: new Date().toISOString() }); setText('') }}>Publicar avaliação</button>
          </div>
        ) : <p className="text-sm text-muted">{reviewed ? 'Você já avaliou este produto.' : 'Só quem comprou este produto pode avaliar. Depois da compra, volte aqui.'}</p>}
        {!mine.length && <p className="text-muted">Ainda não há comentários de compradores.</p>}
        {mine.map((x, k) => <div key={k} className="card p-4"><p className="flex items-center gap-2 text-sm"><Stars value={x.rating} /><b>@{x.user}</b><span className="text-muted">{new Date(x.date).toLocaleDateString('pt-BR')}</span></p><p className="mt-2">{x.text}</p></div>)}
      </section>
    </div>
  )
}

export function CartPage() {
  const products = useCatalog()
  const { cart, setQty, remove } = useStore()
  const [coupon, setCoupon] = useState('')
  const [applied, setApplied] = useState('')
  const items = Object.entries(cart).map(([id, qty]) => ({ p: products.find((x) => x.slug === id)!, qty })).filter((i) => i.p)
  const subtotal = items.reduce((a, i) => a + i.p.price * i.qty, 0)
  const original = items.reduce((a, i) => a + (i.p.old ?? i.p.price) * i.qty, 0)
  const apply = () => { const c = coupon.trim().toUpperCase(); if (c === 'ARTHEMIS10') { setApplied(c); toast('Cupom ARTHEMIS10 aplicado: 10% de desconto') } else toast('Cupom inválido', 'err') }
  const discount = applied === 'ARTHEMIS10' ? subtotal * 0.1 : 0
  const total = subtotal - discount + subtotal * 0.03
  if (!items.length) return <div className="py-20 text-center text-muted"><p className="text-4xl">🛒</p><p>Seu carrinho está vazio.</p><Link to="/marketplace" className="text-primary">Explorar marketplace</Link></div>
  return (
    <div className="grid gap-8 md:grid-cols-[1fr_320px]">
      <div className="space-y-3"><h1 className="text-2xl font-bold">Seu carrinho</h1>
        {items.map(({ p, qty }) => (
          <div key={p.slug} className="flex items-center gap-3 card p-3">
            <span className="text-3xl">{p.emoji}</span>
            <div className="flex-1"><p className="font-medium">{p.name}</p><p className="text-xs text-muted">@{p.seller}</p></div>
            <input aria-label="Quantidade" type="number" min={1} value={qty} onChange={(e) => setQty(p.slug, +e.target.value)} className="input h-9 w-14 px-2" />
            <p className="w-24 text-right">{brl(p.price * qty)}</p>
            <button onClick={() => remove(p.slug)} className="text-danger" aria-label="Remover">✕</button>
          </div>))}
      </div>
      <aside className="space-y-3 card p-5">
        <div className="flex gap-2"><input value={coupon} onChange={(e) => setCoupon(e.target.value)} placeholder="Cupom (ARTHEMIS10)" className="input" /><button onClick={apply} className="btn btn-ghost">Aplicar</button></div>
        {original > subtotal && <p className="flex justify-between text-sm text-muted"><span>Valor original</span><span className="line-through">{brl(original)}</span></p>}
        <p className="flex justify-between text-sm"><span>Subtotal</span>{brl(subtotal)}</p>
        <p className="flex justify-between text-sm"><span>Desconto</span>-{brl(discount)}</p>
        <p className="flex justify-between text-sm"><span>Taxa (3%)</span>{brl(subtotal * 0.03)}</p>
        <p className="flex justify-between text-2xl font-bold text-primary"><span>Total</span>{brl(total)}</p>
        <Link to="/checkout" state={{ coupon: applied }} className="btn btn-primary w-full">Ir para o pagamento</Link>
        <p className="text-xs text-muted">Pagamento somente via PIX (simulado).</p>
      </aside>
    </div>
  )
}

export function Login() {
  const login = useStore((s) => s.login)
  const nav = useNavigate()
  const [mode, setMode] = useState<'buyer' | 'seller'>('buyer')
  const [email, setEmail] = useState('demo@arthemis.com')
  const [pw, setPw] = useState('')
  const [err, setErr] = useState('')
  const [loading, setLoading] = useState(false)
  const tabs = [['buyer', 'Comprador', ShoppingBag], ['seller', 'Vendedor', Store]] as const
  const go = { buyer: '/dashboard', seller: '/vendedor', admin: '/admin' }
  const pick = (m: 'buyer' | 'seller') => { setMode(m); setEmail(m === 'buyer' ? 'demo@arthemis.com' : 'vendedor@arthemis.com'); setPw(''); setErr('') }
  const buyer = mode === 'buyer'
  return (
    <form className="mx-auto max-w-2xl space-y-4" onSubmit={(e) => { e.preventDefault(); setErr(''); setLoading(true); setTimeout(async () => { let r = login(email, pw, mode); let msg = 'E-mail ou senha inválidos.'; if (!r) { const a = await authLogin(email, pw, mode); if (a.ok) r = a.role ?? null; else if (a.err) msg = a.err } setLoading(false); if (r) nav(go[r]); else setErr(msg) }, 600) }}>
      <h1 className="text-4xl">Entrar</h1>
      <div className="grid grid-cols-2 gap-3" role="tablist" aria-label="Tipo de conta">
        {tabs.map(([id, label, Icon]) => (
          <button key={id} type="button" role="tab" aria-selected={mode === id} onClick={() => pick(id)} className={`flex h-12 items-center justify-center gap-2 rounded-full border text-base transition ${mode === id ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:border-primary'}`}><Icon className="h-5 w-5" />{label}</button>
        ))}
      </div>
      <div className="card space-y-4 p-6">
        <p className="text-muted">{buyer ? 'Compre produtos digitais, acompanhe pedidos e acesse seu cofre.' : 'Venda produtos digitais, gerencie seus pedidos e acompanhe seus ganhos.'}</p>
        <label className="block">E-mail<input className="input mt-2 h-12" aria-invalid={!!err} type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></label>
        <label className="block">Senha<input className="input mt-2 h-12" aria-invalid={!!err} type="password" value={pw} onChange={(e) => setPw(e.target.value)} required /></label>
        {err && <p role="alert" className="alert alert-error">{err}</p>}
        <button className="btn btn-primary h-12 w-full" disabled={loading} aria-busy={loading}>Entrar como {buyer ? 'comprador' : 'vendedor'}</button>
        <p className="text-xs text-muted">Demo: {buyer ? 'demo@arthemis.com' : 'vendedor@arthemis.com'} / 123456</p>
        <p className="text-sm">Ainda não tem conta? <Link to={`/cadastro${buyer ? '' : '?tipo=vendedor'}`} className="text-primary">Criar conta</Link></p>
      </div>
    </form>
  )
}

export function Favorites() {
  const products = useCatalog()
  const favs = useStore((s) => s.favs)
  const items = products.filter((p) => favs.includes(p.slug))
  return (<div className="space-y-4"><h1 className="text-2xl font-bold">Meus favoritos</h1>
    {items.length ? <Grid items={items} /> : <div className="py-16 text-center text-muted"><p className="text-4xl">♡</p><p>Você ainda não possui favoritos.</p><Link to="/marketplace" className="text-primary">Explorar marketplace</Link></div>}</div>)
}

export function Dashboard() {
  const { user, favs, cart, balance, orders } = useStore()
  if (!user) return <Navigate to="/login" replace />
  const stats = [['Saldo', brl(balance)], ['Compras', String(orders.length)], ['Favoritos', String(favs.length)], ['No carrinho', String(Object.keys(cart).length)]]
  return (<div className="space-y-4"><h1 className="text-2xl font-bold">Olá, {user}</h1>
    <div className="grid grid-cols-2 gap-3 md:grid-cols-4">{stats.map(([k, v]) => <div key={k} className="card p-5"><p className="text-sm text-muted">{k}</p><p className="text-2xl font-bold">{v}</p></div>)}</div></div>)
}

import { products } from './data'
export type Person = { id: string; name: string; email: string; type: 'Comprador' | 'Vendedor'; since: string }
// Cadastros de exemplo exibidos no Admin (o site ainda não tem cadastro real de usuários)
export const USERS: Person[] = [
  { id: 'demo@arthemis.com', name: 'Demo', email: 'demo@arthemis.com', type: 'Comprador', since: '2026-03-12' },
  { id: 'vendedor@arthemis.com', name: 'Vendedor', email: 'vendedor@arthemis.com', type: 'Vendedor', since: '2026-04-02' },
  { id: 'maria@email.com', name: 'Maria S.', email: 'maria@email.com', type: 'Comprador', since: '2026-05-20' },
  { id: 'joao@email.com', name: 'João P.', email: 'joao@email.com', type: 'Comprador', since: '2026-06-08' },
  { id: 'ana@email.com', name: 'Ana L.', email: 'ana@email.com', type: 'Comprador', since: '2026-07-15' },
  { id: 'lucas@email.com', name: 'Lucas M.', email: 'lucas@email.com', type: 'Comprador', since: '2026-08-03' },
  { id: 'bia@email.com', name: 'Beatriz R.', email: 'bia@email.com', type: 'Comprador', since: '2026-09-01' },
]
export const SELLERS = [...new Set(products.map((p) => p.seller))]
const SINCE = ['2025-11-04', '2026-01-17', '2026-02-09', '2026-03-25', '2026-04-30', '2026-06-12']
export const SELLERS_INFO: Person[] = SELLERS.map((s, i) => ({ id: s, name: '@' + s, email: `contato@${s.toLowerCase()}.com`, type: 'Vendedor' as const, since: SINCE[i % SINCE.length] }))
export const fmtDay = (d: string) => d.split('-').reverse().join('/')

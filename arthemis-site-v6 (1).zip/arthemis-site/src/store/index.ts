import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { toast } from '../toast'
import { can } from '../features/auth/auth'
export type Review = { slug: string; user: string; rating: number; text: string; date: string }
export type Withdrawal = { id: string; date: string; source: 'buyer' | 'seller'; amount: number; type: string; key: string }
export type Role = 'buyer' | 'seller' | 'admin'
// Contas de demonstração. ATENÇÃO: isto roda no navegador, então qualquer pessoa que abrir o código vê estas senhas.
// Para um site real, o login precisa ser feito em um servidor. Troque a senha do admin antes de publicar qualquer coisa.
const ACCOUNTS: { email: string; pw: string; name: string; role: Role }[] = [
  { email: 'demo@arthemis.com', pw: '123456', name: 'Demo', role: 'buyer' },
  { email: 'vendedor@arthemis.com', pw: '123456', name: 'Vendedor', role: 'seller' },
  { email: 'admin@arthemis.com', pw: 'Adm#Arthemis2026', name: 'Admin', role: 'admin' },
]
export type Msg = { from: 'user' | 'admin'; text: string; date: string }
export const T_STATUS = { aberto: 'Aberto', atendimento: 'Em atendimento', aguardando: 'Aguardando usuário', resolvido: 'Resolvido', fechado: 'Fechado' } as const
export const D_STATUS = { nova: 'Nova', analise: 'Em análise', respondida: 'Respondida', resolvida: 'Resolvida', encerrada: 'Encerrada' } as const
export type Status = keyof typeof T_STATUS | keyof typeof D_STATUS
export const statusLabel = (s: string): string => (T_STATUS as Record<string, string>)[s] ?? (D_STATUS as Record<string, string>)[s] ?? s
export const CLOSED: Status[] = ['fechado', 'encerrada']
export type Ticket = { id: string; user: string; kind: 'ticket' | 'denuncia'; topic: string; subject: string; target?: string; reason?: string; related?: string; date: string; updated: string; status: Status; msgs: Msg[] }
export type EventKind = 'premio' | 'sorteio' | 'disputa'
export type EventItem = { id: string; kind: EventKind; name: string; description: string; rules: string; prize: string; start: string; end: string; eligible: 'todos' | 'compradores' | 'vendedores'; metric?: 'sales' | 'revenue' | 'purchases' | 'affiliate'; participants: string[]; scores: Record<string, number>; winner?: string; ranking?: [string, number][]; finished?: boolean }
export type EventStatus = 'proximo' | 'ativo' | 'encerrado' | 'finalizado'
export const eventStatus = (e: EventItem): EventStatus => { if (e.finished) return 'finalizado'; const t = new Date().toISOString().slice(0, 10); return t < e.start ? 'proximo' : t > e.end ? 'encerrado' : 'ativo' }
export type Order = { id: string; date: string; total: number; ref?: string; items: { slug: string; qty: number; key: string }[] }
const code = () => Math.random().toString(36).slice(2, 6).toUpperCase()
const ago = (d: number) => new Date(Date.now() - d * 864e5).toISOString()
const seed = (id: string, user: string, kind: Ticket['kind'], topic: string, subject: string, text: string, d: number, target?: string, reason?: string, related?: string): Ticket => ({ id, user, kind, topic, subject, target, reason, related, date: ago(d), updated: ago(d), status: kind === 'denuncia' ? 'nova' : 'aberto', msgs: [{ from: 'user', text, date: ago(d) }] })
// Tickets e denúncias de exemplo (ids "EX-") para o Admin não ficar vazio
const seedTickets: Ticket[] = [
  seed('EX-T1', 'Maria S.', 'ticket', 'Dúvida', 'Como recebo a chave do produto?', 'Paguei o PIX e não sei onde vejo a chave do produto que comprei.', 1),
  seed('EX-T2', 'João P.', 'ticket', 'Problema', 'Saldo não apareceu', 'Adicionei saldo por PIX e ele ainda não apareceu na minha conta.', 2),
  seed('EX-D1', 'Ana L.', 'denuncia', 'Denúncia', 'Conta entregue diferente do anúncio', 'A conta que recebi tem menos itens do que o anunciado.', 1, '@ProGamer', 'Produto diferente do anunciado', 'Pedido PED-EX01'),
  seed('EX-D2', 'Lucas M.', 'denuncia', 'Denúncia', 'Anúncio suspeito', 'O preço está muito abaixo do normal e pede contato fora da plataforma.', 3, 'Anúncio: Moedas FC 100k', 'Fraude ou golpe', 'Produto Moedas FC 100k'),
]
const day = (n: number) => new Date(Date.now() + n * 864e5).toISOString().slice(0, 10)
const ev = (id: string, kind: EventKind, name: string, description: string, rules: string, prize: string, a: number, b: number, extra: Partial<EventItem> = {}): EventItem => ({ id, kind, name, description, rules, prize, start: day(a), end: day(b), eligible: 'todos', participants: [], scores: {}, ...extra })
const P = ['Maria S.', 'João P.', 'Ana L.', 'Lucas M.', 'Beatriz R.']
// Eventos de exemplo: o administrador pode editar, excluir ou criar novos na aba Eventos do Admin
const seedEvents: EventItem[] = [
  ev('EV-P1', 'premio', 'Top vendedores do mês', 'Premiação para quem mais vendeu no período.', 'Vale o valor total vendido entre as datas do evento.', 'R$ 500 em saldo', -20, 10, { metric: 'sales', eligible: 'vendedores' }),
  ev('EV-P2', 'premio', 'Maior comprador do mês', 'Premiação para quem mais comprou no período.', 'Vale o valor total gasto em compras entre as datas do evento.', 'R$ 300 em saldo', -20, 10, { metric: 'purchases', eligible: 'compradores' }),
  ev('EV-P3', 'premio', 'Campeão dos afiliados', 'Premiação para quem mais vendeu como afiliado.', 'Vale a comissão gerada pelo seu link de afiliado.', 'R$ 300 em saldo', -20, 10, { metric: 'affiliate' }),
  ev('EV-P4', 'premio', 'Maior faturamento', 'Premiação para o vendedor com maior faturamento líquido.', 'Vale o valor das vendas menos a taxa da plataforma.', 'R$ 500 em saldo', -20, 10, { metric: 'revenue', eligible: 'vendedores' }),
  ev('EV-S1', 'sorteio', 'Gift Card Steam R$ 100', 'Sorteio de um gift card Steam.', 'Cada participante concorre com uma chance. O sorteio é feito pelo administrador ao fim do prazo.', 'Gift Card Steam R$ 100', -5, 25, { participants: P.slice(0, 4) }),
  ev('EV-S2', 'sorteio', '3 meses de Netflix', 'Sorteio de uma assinatura Netflix.', 'Aberto a compradores. O sorteio é feito pelo administrador.', 'Netflix 3 meses', 10, 40, { eligible: 'compradores' }),
  ev('EV-S3', 'sorteio', 'Sorteio de setembro', 'Sorteio já realizado.', 'Participantes de setembro.', 'R$ 200 em saldo', -40, -10, { participants: P, winner: 'Maria S.', finished: true }),
  ev('EV-D1', 'disputa', 'Arthemis Cup Valorant 5v5', 'Torneio entre usuários.', 'Cada vitória vale 3 pontos. Vence quem somar mais pontos.', 'R$ 300 em saldo', 5, 7, { participants: P.slice(0, 3) }),
  ev('EV-D2', 'disputa', 'Mata-mata EA FC 1v1', 'Disputa 1v1 entre usuários.', 'Vitória vale 3 pontos e empate 1 ponto.', 'R$ 150 em saldo', -1, 3, { participants: P, scores: { 'Maria S.': 9, 'João P.': 6, 'Ana L.': 4, 'Lucas M.': 3, 'Beatriz R.': 1 } }),
  ev('EV-D3', 'disputa', 'ARAM Battle League of Legends', 'Partidas rápidas entre usuários.', 'Vence quem acumular mais partidas ganhas.', 'Gift Card Riot R$ 100', 8, 12),
]
// Admin precisa da função E da permissão da ação (o Admin 01 tem todas). Veja src/features/auth/auth.ts
const isAdmin = (perm: string) => useStore.getState().role === 'admin' && can(perm)
interface State {
  cart: Record<string, number>; favs: string[]; theme: 'dark' | 'light'; user: string | null; role: Role; email: string | null; balance: number
  reviews: Review[]; orders: Order[]; sellerBalance: number; ref: string; withdrawals: Withdrawal[]; received: string[]; fees: { platform: Record<string, number>; aff: number }
  add: (id: string) => void; remove: (id: string) => void; setQty: (id: string, q: number) => void; clear: () => void
  addBalance: (n: number) => void; toggleFav: (id: string) => void; toggleTheme: () => void; login: (email: string, pw: string, as: 'buyer' | 'seller') => Role | null; logout: () => void
  addReview: (r: Review) => void; placeOrder: (items: { slug: string; qty: number }[], total: number) => void
  setRef: (r: string) => void; withdraw: (src: 'buyer' | 'seller', amount: number, type: string, key: string) => boolean
  markReceived: (ids: string[]) => void; setFee: (seller: string, pct: number) => void; setAff: (pct: number) => void
  removed: { users: string[]; sellers: string[] }; tickets: Ticket[]; events: EventItem[]
  removeEntity: (k: 'users' | 'sellers', id: string) => void; restoreEntity: (k: 'users' | 'sellers', id: string) => void; removeReview: (r: Review) => void
  openTicket: (t: { kind: Ticket['kind']; topic: string; subject: string; target?: string; reason?: string; related?: string; text: string }) => boolean
  replyTicket: (id: string, from: Msg['from'], text: string) => void; setTicketStatus: (id: string, s: Status) => void
  joinEvent: (id: string) => void; saveEvent: (e: EventItem) => void; deleteEvent: (id: string) => void
  drawWinner: (id: string) => void; finishEvent: (id: string, ranking?: [string, number][]) => void; setScore: (id: string, name: string, score: number) => void
}
export const useStore = create<State>()(persist((set, get) => ({
  cart: {}, favs: [], theme: 'dark', user: null, role: 'buyer', email: null, balance: 0, reviews: [], orders: [], sellerBalance: 8294, ref: '', withdrawals: [], received: [], fees: { platform: {}, aff: 5 }, removed: { users: [], sellers: [] }, tickets: seedTickets, events: seedEvents,
  addBalance: (n) => set((s) => ({ balance: s.balance + n })),
  add: (id) => { set((s) => ({ cart: { ...s.cart, [id]: (s.cart[id] ?? 0) + 1 } })); toast('Adicionado ao carrinho') },
  remove: (id) => set((s) => { const c = { ...s.cart }; delete c[id]; return { cart: c } }),
  setQty: (id, q) => (q < 1 ? get().remove(id) : set((s) => ({ cart: { ...s.cart, [id]: q } }))),
  clear: () => set({ cart: {} }),
  toggleFav: (id) => { const has = get().favs.includes(id); set((s) => ({ favs: has ? s.favs.filter((f) => f !== id) : [...s.favs, id] })); toast(has ? 'Removido dos favoritos' : 'Adicionado aos favoritos') },
  toggleTheme: () => set((s) => ({ theme: s.theme === 'dark' ? 'light' : 'dark' })),
  login: (email, pw, as) => {
    const e = email.trim().toLowerCase()
    const a = ACCOUNTS.find((x) => x.email === e && x.pw === pw && !get().removed.users.includes(e))
    // O admin entra por qualquer aba (não existe opção de admin na tela); as demais contas precisam bater com a aba escolhida
    if (!a || (a.role !== 'admin' && a.role !== as)) return null
    set({ user: a.name, role: a.role, email: a.email })
    return a.role
  },
  logout: () => set({ user: null, role: 'buyer', email: null }),
  addReview: (r) => { set((s) => ({ reviews: [r, ...s.reviews] })); toast('Avaliação publicada') },
  placeOrder: (items, total) => set((s) => ({ orders: [{ id: 'PED-' + code() + code(), date: new Date().toISOString(), total, ref: s.ref || undefined, items: items.map((i) => ({ ...i, key: `ARTH-${code()}-${code()}-${code()}` })) }, ...s.orders] })),
  setRef: (r) => set({ ref: r }),
  withdraw: (src, amount, type, key) => {
    const s = get(), avail = src === 'buyer' ? s.balance : s.sellerBalance, k = key.trim(), d = k.replace(/\D/g, '')
    const okKey = type === 'cpf' ? d.length === 11 : type === 'tel' ? d.length >= 10 && d.length <= 11 : type === 'email' ? /^\S+@\S+\.\S+$/.test(k) : k.length >= 32
    if (!okKey) { toast('Chave PIX inválida', 'err'); return false }
    if (!(amount >= 10)) { toast('O valor mínimo para saque é R$ 10,00', 'err'); return false }
    if (amount > avail) { toast('Saldo insuficiente', 'err'); return false }
    const w: Withdrawal = { id: 'SAQ-' + code() + code(), date: new Date().toISOString(), source: src, amount, type, key: '••••' + k.slice(-4) }
    const left = (v: number) => Math.round((v - amount) * 100) / 100
    set((x) => ({ ...(src === 'buyer' ? { balance: left(x.balance) } : { sellerBalance: left(x.sellerBalance) }), withdrawals: [w, ...x.withdrawals] }))
    toast('Saque solicitado: o PIX será enviado (simulado)')
    return true
  },
  markReceived: (ids) => { if (!isAdmin('manage_payments')) return; set((s) => ({ received: [...new Set([...s.received, ...ids])] })); toast('Recebimento confirmado') },
  setFee: (seller, pct) => isAdmin('manage_payments') && set((s) => ({ fees: { ...s.fees, platform: { ...s.fees.platform, [seller]: Math.min(100, Math.max(0, pct)) } } })),
  setAff: (pct) => isAdmin('manage_payments') && set((s) => ({ fees: { ...s.fees, aff: Math.min(100, Math.max(0, pct)) } })),
  removeEntity: (k, id) => { if (!isAdmin(k === 'users' ? 'manage_users' : 'manage_sellers')) return; set((s) => ({ removed: { ...s.removed, [k]: [...s.removed[k], id] } })); toast(k === 'users' ? 'Usuário removido' : 'Vendedor removido e produtos ocultados') },
  restoreEntity: (k, id) => { if (!isAdmin(k === 'users' ? 'manage_users' : 'manage_sellers')) return; set((s) => ({ removed: { ...s.removed, [k]: s.removed[k].filter((x) => x !== id) } })); toast('Restaurado') },
  removeReview: (r) => { if (!isAdmin('manage_reviews')) return; set((s) => ({ reviews: s.reviews.filter((x) => !(x.slug === r.slug && x.user === r.user && x.date === r.date)) })); toast('Avaliação removida') },
  openTicket: (t) => {
    const user = get().user
    if (!user) { toast('Entre na sua conta para abrir um ticket', 'err'); return false }
    const now = new Date().toISOString(), rep = t.kind === 'denuncia'
    const tk: Ticket = { id: (rep ? 'D-' : 'T-') + code() + code(), user, kind: t.kind, topic: t.topic, subject: t.subject, target: t.target, reason: t.reason, related: t.related, date: now, updated: now, status: rep ? 'nova' : 'aberto', msgs: [{ from: 'user', text: t.text, date: now }] }
    set((s) => ({ tickets: [tk, ...s.tickets] }))
    toast(rep ? 'Denúncia enviada' : 'Ticket aberto: responderemos por aqui')
    return true
  },
  replyTicket: (id, from, text) => {
    const s = get(), tk = s.tickets.find((t) => t.id === id)
    if (!tk) return
    if (from === 'admin' ? !isAdmin(tk.kind === 'denuncia' ? 'manage_reports' : 'manage_tickets') : tk.user !== s.user || CLOSED.includes(tk.status)) return
    const rep = tk.kind === 'denuncia', now = new Date().toISOString()
    const status: Status = from === 'admin' ? (rep ? 'respondida' : 'aguardando') : rep ? 'analise' : 'aberto'
    set((x) => ({ tickets: x.tickets.map((t) => (t.id === id ? { ...t, status, updated: now, msgs: [...t.msgs, { from, text, date: now }] } : t)) }))
    toast('Resposta registrada')
  },
  setTicketStatus: (id, st) => {
    const s = get(), tk = s.tickets.find((t) => t.id === id)
    if (!tk || (!isAdmin(tk.kind === 'denuncia' ? 'manage_reports' : 'manage_tickets') && !(tk.user === s.user && st === 'resolvido'))) return
    set((x) => ({ tickets: x.tickets.map((t) => (t.id === id ? { ...t, status: st, updated: new Date().toISOString() } : t)) }))
  },
  joinEvent: (id) => {
    const s = get(), e = s.events.find((x) => x.id === id), me = s.user
    if (!e || !me) { toast('Entre na sua conta para participar', 'err'); return }
    if (s.role === 'admin') { toast('Administradores não participam dos eventos', 'err'); return }
    if (e.kind === 'premio') return
    const st = eventStatus(e)
    if (st === 'encerrado' || st === 'finalizado') { toast('Este evento já foi encerrado', 'err'); return }
    if ((e.eligible === 'compradores' && s.role !== 'buyer') || (e.eligible === 'vendedores' && s.role !== 'seller')) { toast('Você não é elegível para este evento', 'err'); return }
    const has = e.participants.includes(me)
    set((x) => ({ events: x.events.map((v) => (v.id === id ? { ...v, participants: has ? v.participants.filter((p) => p !== me) : [...v.participants, me] } : v)) }))
    toast(has ? 'Participação cancelada' : 'Participação confirmada!')
  },
  saveEvent: (e) => { if (!isAdmin('manage_events')) return; set((s) => ({ events: s.events.some((x) => x.id === e.id) ? s.events.map((x) => (x.id === e.id ? e : x)) : [e, ...s.events] })); toast('Evento salvo') },
  deleteEvent: (id) => { if (!isAdmin('manage_events')) return; set((s) => ({ events: s.events.filter((x) => x.id !== id) })); toast('Evento excluído') },
  drawWinner: (id) => {
    if (!isAdmin('manage_events')) return
    const e = get().events.find((x) => x.id === id)
    if (!e || !e.participants.length) { toast('Não há participantes para sortear', 'err'); return }
    const w = e.participants[Math.floor(Math.random() * e.participants.length)]
    set((s) => ({ events: s.events.map((x) => (x.id === id ? { ...x, winner: w, finished: true } : x)) }))
    toast(`Vencedor sorteado: ${w}`)
  },
  finishEvent: (id, ranking) => {
    if (!isAdmin('manage_events')) return
    const e = get().events.find((x) => x.id === id)
    if (!e) return
    const r = e.kind === 'disputa' ? Object.entries(e.scores).sort((a, b) => b[1] - a[1]) : ranking
    if (!r || !r.length) { toast('Ainda não há ranking ou pontuação para finalizar', 'err'); return }
    set((s) => ({ events: s.events.map((x) => (x.id === id ? { ...x, ranking: r, winner: r[0][0], finished: true } : x)) }))
    toast('Evento finalizado')
  },
  setScore: (id, name, score) => { if (!isAdmin('manage_events')) return; set((s) => ({ events: s.events.map((x) => (x.id === id ? { ...x, scores: { ...x.scores, [name]: score } } : x)) })) },
}), {
  name: 'arthemis-store',
  version: 2,
  // Converte tickets salvos em versões anteriores para os novos status
  migrate: (persisted, version) => {
    const s = persisted as Partial<State>
    if (version < 2 && s.tickets) {
      const map: Record<string, Record<string, Status>> = { ticket: { respondido: 'aguardando' }, denuncia: { aberto: 'nova', respondido: 'respondida', fechado: 'encerrada' } }
      s.tickets = s.tickets.map((t) => ({ ...t, updated: t.updated ?? t.msgs[t.msgs.length - 1]?.date ?? t.date, status: map[t.kind]?.[t.status as string] ?? t.status }))
    }
    return s as State
  },
}))

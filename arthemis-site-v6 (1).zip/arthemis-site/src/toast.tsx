import { create } from 'zustand'
import { X } from 'lucide-react'

type T = { id: number; msg: string; kind: 'ok' | 'err' }
const useToasts = create<{ items: T[] }>(() => ({ items: [] }))
const close = (id: number) => useToasts.setState((s) => ({ items: s.items.filter((t) => t.id !== id) }))

// Use em qualquer arquivo: toast('Adicionado ao carrinho') ou toast('Cupom inválido', 'err')
export function toast(msg: string, kind: T['kind'] = 'ok') {
  const id = Date.now() + Math.random()
  useToasts.setState((s) => ({ items: [...s.items, { id, msg, kind }] }))
  setTimeout(() => close(id), 3200)
}

export function Toasts() {
  const items = useToasts((s) => s.items)
  return (
    <div className="fixed left-4 bottom-20 z-50 flex max-w-xs flex-col gap-2 md:bottom-4" aria-live="polite">
      {items.map((t) => (
        <div key={t.id} className="fade-up rounded-md bg-card shadow-e2">
          <div className={`alert flex items-center gap-3 ${t.kind === 'ok' ? 'alert-success' : 'alert-error'}`}>
            <span className="flex-1">{t.msg}</span>
            <button aria-label="Fechar aviso" onClick={() => close(t.id)}><X className="h-3.5 w-3.5" /></button>
          </div>
        </div>
      ))}
    </div>
  )
}
